package ReDIF::Parser::NO_UTF8;

#      $Id$
#$VERSION = do { my @r=(q$Revision$=~/\d+/g); sprintf "%d."."%02d"x$#r,@r }; 

#########################################################################
# SUB  R E M E M B E R    A T T R I B U T E     (INCLUDE_ATTRLINE)
#########################################################################
#

# use ReDIF::Unicode;

sub ReDIF::Parser::Core::get_non_utf8_value {

    use bytes;

    my $va = shift;

    return $va;
}


1;


