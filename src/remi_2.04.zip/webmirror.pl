################################################################
# Mirror web based RePEc archive
################################################################
#
# This is a specialised spider for mirroring RePEc archives
# and probably pretty useless for anything else.
#
# It takes a limited set of command line arguments and is 
# intended to be run under control of the remi2.pl script.
# The command line arguments can also be read from a 
# configuration file.
# 
# See webmirror.pl -? for the current set of arguments
#
# remi2 writes configuration files (web_a_aaa or web_all_aaa)
# where aaa is the archive code. _a_ for regular mirroring and
# _all_ for the "core" mirror.
#
# use 
#   webmirror.pl -c config_file -d
# or
#   webmirror.pl -c config_file -d
# to diagnose mirroring problems
#
# For mirroring problems also see the config_file.tmp.log that
# remi2 instructs webmirror to write.
#
# Changes
# 1.01
#   Fixed error messages
# 1.02
#   Fixed regexp in is_wanted sub, base url is now quoted in the regexp
# 1.03 2015-03-07
#  Fixed warning about undefined hash element in numerical comparison in the check if we should reschedule
#  Fix for servers returning invalid HTTP-Date in Last-Modified
#  Log more info about resecheduled documents
# 1.04 2015-04-27
#  Try to make mirroring more robust by immediately retrying when server prematurely closes the connection
#  Also reschedule on 502, 503 and 504 response
#  Add accept header to accomodate web servers behaving badly
#  Print more summary information on the mirroring at the end of the log
# 1.05 2015-08-13
#  Retry fetching incomplete html documents, this hopefully fixes problems with mirroring hal
#  Check SSL-certificates (requires Mozilla::CA), nan archive seems to require this, turn off if fail to connect. Will probably do nothing with older versions of Perl.
#  Better mirroring of archive and series templates to all, now tries to extract filename from index document if lower case file name does not work
#  Adapt pause between requests to number of documents to get reasonable mirroring time: HAL!
#
################################################################

use diagnostics;
use strict;

use LWP::UserAgent;
use HTML::LinkExtor;
use HTTP::Cookies;
use HTTP::Date qw( time2str str2time time2iso time2isoz );
use URI::file;
use File::Basename;
use File::Find;
use File::Path qw( make_path );
use Time::HiRes qw( sleep ); # decimals in slepp

# global vars
my $LOGOPEN     = 0;
my $DEBUG       = 0;
my $TOTALMIRROR = 0;
my $MAXRETRY    = 1;
my $DONTDELETE  = 0;
my $ARCHSER     = '';
my $RETRYWAIT   = 600; # 10 minutes
my $WAIT        = 1; # pause between requests
my @URIQUEUE;
my %QUEUED;
my %LOCALFILES;
my %MIRRORED;
my %RESCHEDULED;
my @TORESCHEDULE;
my $NUM_FAILEDREQUESTS = 0;
my $NUM_RETRIEVED = 0;
my $NUM_UNMODIFIED = 0;
my $NUM_DELETED = 0;

# regexps for what we want to mirror unless $TOTALMIRROR is on
# anchored and made case insensitive in the code
my $RE_INDEXDOC   = qr!(?:index|welcome|default)\.(?:html*|php|aspx*)$!i;
my $RE_DIRECTORY  = qr![a-z0-9]{6}(/*|/$RE_INDEXDOC)!i;
my $RE_SPECIALDIR = qr!(?:soft|conf)!i;
my $RE_REDIF      = qr!\.rdf!i;
my $RE_FUNKY_DIR  = qr!(?:[a-z0-9]{6}|(?:index|welcome|default)\.(?:php|aspx*))!i; # directory that looks like a file or scripts, mess with local file name

my $VERSION = 1.05;

main();

#----------------------------------------------------

sub main {

my( @args, $directory, $archiveurl, $logfile, @cfg, $totalmirror,
    $archivebase, $BaseDir, %localdirused, $agent, $archser, $waitset,
    $s, $t );

my $usage =<<_U_;
Usage: $0
 -a User-Agent
 -c config file [text file with command line arguments]
 -d extra debug output (-d -d gives more output)
 -m directory to mirror to
 -o log file
 -t 'total' mirror, default is to only mirror .rdf files and content of 
    soft and conf dirs
 -u archive URL
 -w pause between requests, seconds
 -archser archivecode (three letter), mirror only archive and series templates
_U_

# process arguments
@args = @ARGV;
while( @args ) {
  $s = shift @args;
  if ( $s eq '-a' ) {
    $agent = shift @args;
  } elsif ( $s eq '-archser' ) {
    $archser = shift @args;
  } elsif ( $s eq '-c' ) {
    $t = shift @args;
    open( IN, "<$t" );
    while ( <IN> ) {
      chomp( $_ );
      push @cfg, split / +/;
    }
    close( IN );
    @args = ( @cfg, @args );
  } elsif ( $s eq '-d' ) {
    $DEBUG++;
  } elsif ( $s eq '-m' ) {
    $directory = shift @args;
    $directory .= '/' unless $directory =~ m![\\/]$!;
  } elsif ( $s eq '-o' ) {
    $logfile = shift @args;
  } elsif ( $s eq '-t' ) {
    $totalmirror = 1;
  } elsif ( $s eq '-u' ) {
    $archiveurl = shift @args;
  } elsif ( $s eq '-w' ) {
    $WAIT = shift @args;
    unless ( $WAIT =~ /^\d+$/ ) {
      print "-w must be numeric\n\n";
      print $usage;
      exit;
    }
    $waitset = 1;
  } else {
    print $usage;
    exit;
  }
}
$TOTALMIRROR ||= $totalmirror;
$ARCHSER     ||= $archser;

unless ( $directory and $archiveurl ) {
  print $usage;
  exit;
}

####
my $ascalled = join( ' ', @ARGV );
print "Webmirror start $ascalled\n";
####

$agent ||= 'RePEc archive mirror';

if ( $logfile ) {
  # set up logging
  open( LOG, ">$logfile" ) or die "Can't open logfile $logfile: $@";
  $LOGOPEN = 1;
}

logg( 'Called with arguments ' . join ' ', @ARGV ) if $DEBUG;
logg( 'From config ' . join ' ', @cfg ) if $DEBUG and @cfg;

$archiveurl = URI->new( $archiveurl )->canonical(); 
( $archivebase = $archiveurl ) =~ s!/[^/]+$!/!;
$BaseDir = URI::file->new( $directory );

logg( "Mirroring $archiveurl with base $archivebase to " . $BaseDir->file );

# read local directory
my $wanted = sub {
  my( $reluri ) = URI::file->new( $File::Find::name )->rel( $BaseDir )->file;
  return if $reluri =~ m!^\.!;
  if ( -d $_ ) {
    $LOCALFILES{$reluri} = -1;
  } else {
    my @s = stat( $_ );
    $LOCALFILES{$reluri} = $s[9];
  }
};
find( $wanted, $directory );

# adapt paus between requests to number of documents
if ( !$waitset ) {
  $t = scalar( keys %LOCALFILES );
  if ( $t > 28800 ) {
    $WAIT = 0.1;
    $waitset = 1;
  } elsif ( $t > 14400 ) {
    $WAIT = 0.4;
    $waitset = 1;
  }
  logg( "$t documents, sleeping $WAIT seconds between requests" ) if $waitset;
}

if ( $DEBUG ) {
  logg( '====== Local files ======' );
  foreach $s ( sort keys %LOCALFILES ) {
    $t = $s;
    if ( $LOCALFILES{$s} == -1 ) {
      $t .= ', directory';
    } else {
      $t .= ', ' . time2isoz( $LOCALFILES{$s} );
    }
    logg( $t );
  }
  logg( '=========================' );
}

if ( $archser ) {
  # core mirror of archive and series templates
  
  queue( "$archivebase${archser}arch.rdf", $archivebase, '', 0 );
  queue( "$archivebase${archser}seri.rdf", $archivebase, '', 0 );
  
} else {
  # regular mirror, follow links
  
  queue( $archiveurl, $archivebase, '', 0 );
  
}

mirror( $archivebase, $BaseDir, $agent, $archiveurl );

while ( @TORESCHEDULE ) {
  $t = scalar( @TORESCHEDULE );
  logg( "$t rescheduled documents, sleeping $RETRYWAIT seconds" );
  sleep( $RETRYWAIT );
  @URIQUEUE = @TORESCHEDULE;
  @TORESCHEDULE = ();
  mirror( $archivebase, $BaseDir, $agent, $archiveurl );
}

if ( $DONTDELETE ) {
  
  logg( 'ERROR: Errors in mirroring, files not deleted' );
  
} elsif ( !$archser ) {
  # clean up

  foreach $s ( keys %LOCALFILES ) {
    next if $LOCALFILES{$s} == -1;
    unless ( $MIRRORED{$s} ) {
      logg( "Removing $s" );
      $t = URI::file->new( $s )->abs( $BaseDir )->file;
      if ( -e $t and unlink ( $t ) ) {
        $NUM_DELETED++;
      } else {
        logg( "ERROR: Failed to delete $t" );
      }
    } else {
      $t = dirname( $s );
      $localdirused{$t} = 1;
    }
  }
  foreach $s ( reverse sort keys %LOCALFILES ) {
    # remove directories recursively
    if ( $LOCALFILES{$s} == -1 ) {
      unless ( $localdirused{$s} ) {
        logg( "Removing $s" );
        $t = URI::file->new( $s )->abs( $BaseDir )->file;
        rmdir $t or logg( "ERROR: failed to rmdir $t" );
        # allow some time for the file system to realise that the directory is empty with recursive removals
        sleep( 1 ); 
      }
    }
  }

}

logg( "$NUM_RETRIEVED documents retrieved" );
logg( "$NUM_UNMODIFIED unmodified documents" );
logg( "$NUM_FAILEDREQUESTS documents not retrieved" ) if $NUM_FAILEDREQUESTS;
logg( "$NUM_DELETED documents deleted" ) if $NUM_DELETED;
logg( "Mirror end" );

####
print "Webmirror end $ascalled\n";
####

}

#------------------------------------------------------------------

sub logg {
  
  if ( $LOGOPEN ) {
    print LOG time2iso() . ": $_[0]\n";
  } else {
    print time2iso() . ": $_[0]\n";
  }
  
}

#------------------------------------------------------------------

sub queue {
  
  my( $url, $base, $referer, $first ) = @_;
  
  my( $localname );
  
  $url = URI->new( $url )->canonical();
  $url->fragment( undef );    
  if ( $QUEUED{$url} and not $first == 2 ) {
    logg( "Skip $url, already seen" ) if $DEBUG;
    return;
  }
  if ( "$url/" eq $base ) {
    # idiotic web servers redirecting to directory URL without slash!
    $localname = 'index.html';
  } else {
    # normal case
    if ( not in_scope( $url, $base ) ) {
      logg( "Skip $url, not in scope" ) if $DEBUG;
      return;
    } elsif ( has_query_string( $url ) ) {
      logg( "Skip $url, query string present" ) if $DEBUG;
      return;
    }
    $localname = is_wanted( $url, $base );
    unless ( $localname ) {
      logg( "Skip $url, not proper for RePEc archive" ) if $DEBUG;
      return;
    }
  }
  
  if ( $localname =~ m!/$! ) {
    $localname .= 'index.html';
  } elsif ( $localname =~ m!$RE_FUNKY_DIR$!i ) {
    $localname .= '.html';
  }
  $localname = URI::file->new( $localname )->file;

  if ( $first ) {
    unshift @URIQUEUE, [ $url, $localname, $referer ];
    logg( "Queued $url => $localname at top" ) if $DEBUG;
  } else {
    push @URIQUEUE, [ $url, $localname, $referer ];
    logg( "Queued $url => $localname" ) if $DEBUG;
  }
  $QUEUED{$url} = 1;
  
}

sub in_scope {
  my( $url, $base ) = @_;
  return $url =~ /^\Q$base\E/;
}
sub has_query_string {
  my( $url ) = @_;
  return $url->query;
}
sub is_wanted {
  # returns local filename if OK, otherwise undef
  my( $url, $base ) = @_;
  my $filename = $url->rel( $base );
  if ( $filename eq './' ) {
    return 'index.html';
  } elsif ( $ARCHSER ) {
    return( $filename ) if $filename =~ m!$ARCHSER(arch|seri)\.rdf!i or $filename =~ m!^$RE_INDEXDOC$!i; # only get archive url and archive and series templates
  } elsif ( $TOTALMIRROR or
            $filename =~ m!^$RE_DIRECTORY$!i or
            $filename =~ m!^$RE_INDEXDOC$!i or
            $filename =~ m!^$RE_SPECIALDIR!i or
            $filename =~ m!$RE_REDIF$!i ) {
    return $filename;
  }
}

#------------------------------------------------------------------

sub mirror {

  my( $uribase, $basedir, $agent, $archiveurl ) = @_;
  
  my( $ua, $url, $localname, $referer, $parser, $req, $resp,
      $fulllocalname, $mtime, $dir, $unmodified, $retried_on_close,
      $numretried_on_close, $retried_incomplete, $retried_https );
  
  # set up user agent
  $ua = LWP::UserAgent->new( 'keep_alive' => 5 );
  $ua->cookie_jar( HTTP::Cookies->new );
  $ua->agent( $agent );
  $ua->timeout( 30 ); # 30 seconds timeout
  $ua->protocols_allowed( [ 'http', 'https' ] );
#  $ua->max_redirect( 0 );
  $ua->requests_redirectable( [] );

#  Try with check of SSL certificates, nan archive seems to rrequire this  
#  {
#  no strict "subs";
#  $ua->ssl_opts( 'SSL_verify_mode' => SSL_VERIFY_NONE );
#  }
  
  my $callback = sub {
    my( $tag, %attr ) = @_;
    return unless $tag eq 'a';
    foreach ( values %attr ) {
      queue( URI->new( $_ )->abs( $url ), $uribase, $url, 0 );
    }
  };
  $parser = HTML::LinkExtor->new( $callback );
  
  $unmodified = $retried_on_close = $numretried_on_close = $retried_incomplete = $retried_https = 0;
  while ( @URIQUEUE ) {
    $retried_on_close = $retried_on_close == 1 ? 2 : 0;
    $retried_incomplete = $retried_incomplete == 1 ? 2 : 0;
    $retried_https = $retried_https == 1 ? 2 : 0;
    
    ( $url, $localname, $referer ) = @{ shift @URIQUEUE };
    # set up request
    $req = HTTP::Request->new( 'GET', $url );
    $req->headers->header( 'Accept' => '*/*' );
    if ( $LOCALFILES{$localname} and $localname !~ m!\.html*$! ) {
      # do unconditional get for index documents (local name ends with .html)
      $req->headers->header( 'If-modified-since' => time2str( $LOCALFILES{$localname} ) );
    }
    if ( $referer ) {
      $req->headers->header( 'Referer' => $referer );
    }
    $resp = $ua->simple_request( $req );
    if ( $DEBUG > 1 ) {
      logg( "Request:\nGET " . $resp->request->uri->as_string . "\n" . $resp->request->headers->as_string );
      logg( "Response:\n" . $resp->status_line . "\n" . $resp->headers_as_string );
    }
    $fulllocalname = URI::file->new( $localname )->abs( $basedir )->file;
    if ( $resp->code == 200 ) {
      # save
      logg( "$unmodified not modified documents checked" ) if $unmodified;
      $unmodified = 0;
      logg( "$url => $localname" );
      logg( "INFO: Client-Warning '" . $resp->headers->header( 'Client-Warning' ) . "'" ) if $DEBUG and $resp->headers->header( 'Client-Warning' );
      $dir = dirname( $fulllocalname );
      if ( $ARCHSER and $localname =~ m!\.html*!i ) {
        logg( "INFO: not saving index doc" ); # we don't want this with the all mirror
      } else {
        unless ( -d $dir ) {
          if ( -e $dir ) {
            logg( "ERROR: Cannot create directory $dir, file in the way" );
          } else {
            # create directories more than one level down
            make_path( $dir, {error => \my $err} );
            if ( @$err ) {
              foreach my $diag ( @$err ) {
                my( $file, $mess ) = %$diag;
                logg( "ERROR: Creating dir $file '$mess'" );
              }
            }
          }
        }
        if ( -d $fulllocalname ) {
          logg( "ERROR: Cannot save $fulllocalname, directory in the way" );
        } elsif ( open OUT, ">$fulllocalname" ) {
          binmode OUT;
          print OUT $resp->content;
          close OUT;
          if ( $resp->headers->header( 'Last-Modified' ) ) {
            $mtime = str2time( $resp->headers->header( 'Last-Modified' ) );
          } 
          $mtime = time unless $mtime; # Banca d'Italia web server returns invalid HTTP-Date in Last-Modified (Italian day and month)
          utime( $mtime, $mtime, $fulllocalname ) or
            logg( "ERROR: Failed to set modification time for $fulllocalname" );
          # successfully mirrored
          $MIRRORED{$localname} = 1;
          $NUM_RETRIEVED++;
        } else {
          logg( "ERROR: Failed to save to $fulllocalname" );
          $DONTDELETE = 1;
        }
      }
      # parse and queue
      if (  $fulllocalname =~ /\.html*$/ or lc( $resp->headers->header( 'Content-Type' ) ) eq 'text/html' ) {
        my $content = $resp->content();
        if ( !$retried_incomplete and $content =~ m!<html>!i and $content !~ m!</html>!i ) {
          unless ( $content =~ m!<body>!i and $content =~ m!</body>!i ) {
            # Starting html tag but no closing tag, assume incomplete document retrieved
            # this is for hal archive!
            $retried_incomplete = 1;
            logg( "Incomplete html document, retrying" );
            queue( $url, $uribase, $referer, 2 ); # put at top of queue and ignore that it has already been queued
            next;
          }
        }
        logg( "======= Parsing $localname =============" ) if $DEBUG;
        $parser->parse( $content );
        logg( '================================================' ) if $DEBUG;
      }
    } elsif ( $resp->code == 304 ) {
      $unmodified++;
      $NUM_UNMODIFIED++;
      $MIRRORED{$localname} = 1;
      logg( "$url => $localname, not modified" ) if $DEBUG;
      if ( $fulllocalname =~ /\.html*$/ ) {
        logg( "======= Parsing $localname =============" ) if $DEBUG;
        $parser->parse_file( $fulllocalname );
        logg( '================================================' ) if $DEBUG;
      }
    } elsif ( $resp->is_redirect ) {
      #my $newloc = URI->new( $resp->headers->header( 'Location' ) )->canonical;
      # allow for relative URLs in Location header
      my $newloc = URI->new( $resp->headers->header( 'Location' ) )->abs( $url )->canonical;
      if ( $newloc eq "$url/" ) {
        logg( "Directory without slash, $url" );
        queue( $newloc, $uribase, $referer, 1 ); # put at top of queue
      } elsif ( "$newloc/" eq $uribase ) {
        # idiotic!
        logg( "Redirect (" . $resp->status_line . ") to directory without slash! $newloc" );
        queue( $newloc, $uribase, $referer, 1 ); # put at top of queue
      } elsif ( in_scope( $newloc, $uribase ) and not has_query_string( $newloc ) and is_wanted( $newloc, $uribase ) ) {
        logg( "$url redirected (" . $resp->status_line . ") to $newloc, referred from $referer" );
        queue( $newloc, $uribase, $referer, 1 ); # put at top of queue
      } else {
        logg( "ERROR: '" . $resp->status_line . "' $url redirected to $newloc, referred from $referer" );
        $DONTDELETE = 1;
      }
    } else {
      my $doreschedule = 0;
      my $status = $resp->status_line;
      my @tmp = $resp->headers->header( 'Client-Warning' );
      if ( $resp->code == 500 ) { 
        # Internal Server Error from server or internal error code from LWP
        if ( @tmp ) {
          # internal error from LWP
          if ( !$retried_on_close and $status =~ /(Server closed connection without sending any data back|Status read failed|write failed|read timeout)/ ) {
            # Connection prematurely closed, do one immediate retry
            $retried_on_close = 1;
            $numretried_on_close++;
            if ( $DEBUG ) {
              logg( "ERROR: '" . $resp->status_line . "' when getting $url, referred from $referer" );
              logg( "INFO: Client-Warning '" . join( '; ', @tmp ) . "'" ) if @tmp;
              logg( "Retrying $url" );
            }
            queue( $url, $uribase, $referer, 2 ); # put at top of queue and ignore that it has already been queued
            next;
          } elsif ( !$retried_https and $url->scheme eq 'https' and $status =~ /Can't connect to/ ) { #'
            # try disabling SSL verification, mur seems to need this
            no strict "subs";
            $retried_https = 1;
            $ua->ssl_opts( 'SSL_verify_mode' => SSL_VERIFY_NONE );
            if ( $DEBUG ) {
              logg( "ERROR: '" . $resp->status_line . "' when getting $url, referred from $referer" );
              logg( "INFO: Client-Warning '" . join( '; ', @tmp ) . "'" ) if @tmp;
              logg( "Retrying $url" );
            }
            logg( "Turning off SSL verification" );
            queue( $url, $uribase, $referer, 2 ); # put at top of queue and ignore that it has already been queued
            next;
          } elsif ( $status =~ /Can't connect to/ ) { #'
            # wait for this one
            $doreschedule = 1;
          }
        }
      } elsif ( $resp->code >= 502 and $resp->code <= 504 ) {
        # 502, bad gateway
        # 503, service temporarily unavailable
        # 504, gateway timeout
        $doreschedule = 1;
      } elsif ( $ARCHSER and $resp->code == 404 and $localname =~ m!^$RE_REDIF$!i and $localname eq lc($localname) ) {
        queue( $archiveurl, $uribase, '', 0 ); # Try to get actual filenames in case lowercased filenames doesn't work
      }

      if ( $doreschedule and ( !$RESCHEDULED{$url} or $RESCHEDULED{$url} < $MAXRETRY ) ) {
        $RESCHEDULED{$url}++;
        push @TORESCHEDULE, [ $url, $localname, $referer ];
      } else {
        $doreschedule = 0;
        $DONTDELETE = 1;
        $NUM_FAILEDREQUESTS++;
      }
      logg( "ERROR: '" . $resp->status_line . "' when getting $url, referred from $referer" );
      logg( "INFO: Client-Warning '" . join( '; ', @tmp ) . "'" ) if @tmp;
      logg( "Headers:\n" . $resp->headers->as_string ) if $DEBUG == 1;
      logg( "Rescheduling $url" ) if $doreschedule;
    }

    sleep( $WAIT );
    
  }
  logg( "$unmodified not modified documents checked" ) if $unmodified;
  logg( "$numretried_on_close documents retried on premature close of connection" ) if $numretried_on_close;

  
}