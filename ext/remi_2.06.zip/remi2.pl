#!/usr/bin/perl

#
# script: remi
# mirror remote archives
#
# use:
# remi -?
# for useage
#
# Original script by J.M. Barrueco
#
# NT port by Sune Karlsson (Sune.Karlsson@oru.se)
#   Should hopefully run on other platforms as well 
#
#  -- 2016-03-19, 2.06
#        - Mirror .redif files as well as .rdf
#        - webmirror updated to 1.07
#  -- 2015-12-17, 2.05
#        - Check that handle in archive template matches file name
#        - Check for multiple archive or series template files for archive (difference in case) in all mirror
#        - Various fixes to webmirror, version 1.06
#  -- 2015-08-13, 2.04
#        - Try to deal with duplicate archive templates in all. Now issues error message about duplicates.
#        - Various fixes to webmirror, version 1.05
#  -- 2015-04-27, 2.03
#        - Updated webmirror.pl to 1.04, see webmirror.pl file for details
#  -- 2015-03-16, 2.02
#        - Fixed issues with scheduling option %run_wait in config which caused archive to be mirrored twice
#        - Disabled $run_first and %run_wait from config if archive to mirror is given on command line
#        - Improved detection of valid archive template files in all-mirror (now uses ReDIF-Perl to see if file
#          contains valid archive or series template (previously heuristic check of archive templates only)
#        - Fix for potential problem with all-mirror overwriting manually updated achive templates with old templates 
#          (has to do with check that archive templates are valid ReDIF files)
#        - webmirror: Fix for servers returning invalid HTTP-Date in Last-Modified
#        - webmirror: Log more info about resecheduled documents
#  -- 2014-11-21, 2.01
#        - Better parsing of error messages from webmirror, removed some inconcistences in error messages
#        - webmirror failed to mirror archives with "unusual" characters (i.e. those who needs to be 
#          escaped in a regexp) in the archive URL. Fixed.
#  -- 2014-10-06, 2.0
#        - Major rewrite
#        - replaced w3mir by custom webspider, webmirror.pl, that can do https
#          webmirror.pl should deal better with webservers that do not enforce that directory URLs end with a slash
#          webmirror.pl will percent escape filenames for robustness
#          logformat is different from w3mir, log file is web.log
#        - options for mirroring series or excluding series removed
#        - new directives, $run_first and %run_wait to give some control over scheduling of archives with $parallel
#  -- 2014-07-11, 1.5r
#        - Added Pragma: no-cache header to avoid problem with stupid servers that close the 
#          connection if the request for a directory contains exactly three headers. 
#          This affected the jso, srs, afe, ntj and bap archives.
#        - Made detection of errors in w3mir mirroring more specific to avoid false "positives"
#        - Fixed problems with html comments containing html mark-up
#  -- 2013-09-16, 1.5q
#        - Fixed deprecation warnings introduced in Perl 5.16
#        - Fixed issue when w3mir attempted to unlink an open file (happened when the size of the received document didn't match the header)
#        - Make mirror retry once if it fails connecting to ftp server (this should have been in 1.5o, but somehow didn't make it)
#  -- 2012-09-13, 1,5p
#        - Fixed problem with double slash in path segment of http URL which caused files to be written in
#          the root of the file system rahter than the archive directory under remo (ufb archive). Now removes
#          all double slashes in path segment when creating file names.
#        - Minor fix with index documents in http archives.
#  -- 2012-09-11, 1.5o
#        - Added mirroring wall time to log for parallell mirroring, minor mod to logging with $log_parallel
#        - Make mirror retry (once) when attempt to connect to ftp server fails.
#  -- 2011-11-09, 1.5n
#        - Bugfix. The regexp parsing the response from the SITE DIRSTYLE command was to specific (ftp4remi.pl)
#  -- 2011-09-18, 1.5m
#        - Make flags for directory listing with ftp mirroring configurable, needed to disable flags with
#          ftp.drivehq.com since it now returns empty listings if there are flags present. $ls_flags{server}
#          config setting.
#  -- 2011-07-16, 1.5l
#        - Fix bug with archives in the root of the server and no trailing slash on the archive url
#          in the template (last character of the server name was interpreted as the path). Adds URI 
#          as a preequisite.
#  -- 2011-01-07, 1,5k
#        - Add detection of 
#          "Insufficient details for package to be fetched
#          Must give at least: site, remote_user, remote_dir and local_dir"
#          error message from mirror.
#        - Add fix to avoid this error when archive is placed in root of ftp server e.g. 
#          URL: ftp://ftp.example.com/
#          (the remote_dir directive in the package file was empty)
#        - Add detection of "w3mir: Server indicated authentication failure but gave no www-authenticate reply"
#          error message.
#  -- 2010-04-26, 1.5j
#        - Read templates as UTF-8, i.e. turn on the ReDIF-Perl utf8_output option 
#  -- 2010-03-17, 1.5i
#        - Make regexp for excluding directories generated by FrontPage more specific. 
#          m!/_vti_.+/! instead of m!/_.+/!
#          This fixes a problem with mirroring the fpo archive which has a segment _files_ in the URL.
#  -- 2009-12-29, 1.5h
#        - Extended "index documents" to allow aspx, (?:index|welcome|default)\.(?:html*|php|aspx*)
#        - Allow redirect of start url to "index document".
#        - Catch host lookup failures with w3mir (99 response code) in logs
#        - Fix processing of passive/active ftp settings so that $pasv_no{host} overrides
#          $pasv_non21 as well as $pasv_all.
#  -- 2009-04-06, 1.5g
#        - Fixed bug in Fetch-RE for w3mir that caused it to mirror arbitrary directory structures
#          with $redifonly = 1 instead of just conf, soft and six character directories.
#        - mirror tries to send a SITE DIRSTYLE command if the directory listing appears to be
#          empty (can not be parsed). If successful tries to get the directory listing again.
#          DIRSTYLE is a command specific to the IIS ftp server that flips between Unix and 
#          MS-DOS style directory listings.
#  -- 2008-11-03, 1.5f
#        - Does an unconditional get for index files and directories.
#          This ensures that we always get the current index file from the
#          archive even if this is older than our copy.
#        - Added $shortlogmail, $mainlogs2keep, $errlogs2keep and $remilogs2keep config settings
#          for better control of logging and how much log info is e-mailed
#        - Added $archive_timeout{$arch} config setting for per archive override of 
#          mirror and w3mir time outs.
#        - Added error message for non ftp or http archive URLs.
#        - Allowed names for "index files" in archive URL and series directories expanded to
#          (index|welcome|default)\.(html*|php|asp)
#  -- 2008-04-18, 1.5e
#        - Change w3mir user agent string so we don't get blocked by clueless modsecurity
#          users.
#  -- 2007-08-19, 1.5d
#        - Fixed reversed mirroring locations in log for mirror of all
#        - Fix in mirror4remi.pl to work around stupid DNS admins who put 127.0.0.1 in
#          the DNS. Requires lchat4remi.pl.
#        - Allow archive URLs that references explicit index files for http based
#          archives.  File names should match (index|welcome|default)\.html*
#        - Try catching 300 Multiple Choices responses (as an error) from http servers in parsing
#          of w3mir log.
#        - Added $pasv_non21 config setting. This turns on passive ftp for servers that
#          listens on other ports than the standard port, 21.
#  -- 2007-01-10, 1.5c
#        - Handle html-entities in URLs mined from html documents, w3mir4remi now uses
#          htmlop4remi.pm.
#        - Better parsing of error messages from w3mir to catch cases when we reschedule
#          due to 'error in recv'
#  -- 2006-10-18, 1.5b
#        - Stop turning on PASV as default with non-standard ports
#        - Make PASV configurable on a host-by-host basis, $pasv_all, %pasv_no and %pasv_host
#          $pasv_all = 1 is equivalent to $mirror_options = "passive_ftp=true\n"
#        - Keep backups of tmp log files, $logfiles2keep in remi.conf, mainly useful for
#          for the RePEc Data Check
#        - Made w3mir retry the GET on additional error conditions
#  -- 2006-04-22, 1.5a
#        - Fixed problem with File::Copy behaving differently on Unix and Windows.
#          Filetimes are now explicitly preserved on copied files for the core mirror.
#        - Added -makeallold command line option. This resets the file times for all .rdf
#          files in the all directory (as specified by $local_all_directory) to 1997-01-01.
#  -- 2006-03-25, 1.5
#        - Added check that downloaded archive and series templates
#          are ReDIF files before overwriting local copy when mirroring
#          to core site (all.repec.org). This works by mirroring to a temporary
#          directory, checking files and only copying to 'all' if they look like a ReDIF 
#          file. Check is primitive only that the first non-blank line starts with
#          Template-type. Only archive templates are checked.
#        - More flexible (and logical?) specification of directory structure.
#          Undocumented $all option renamed to $local_all_directory
#          this controls from which directory remi will read archive templates
#          and mine archive URLs. Default is RePEc/remo/all.
#          New option $local_mirror_dir (replaces the $directory option), this controls which directory a
#          a regular mirror will mirror to. Archive abc is mirrored to $local_mirror_dir/abc.
#          Also affects the default directory for the mirror to the core site.
#          Default is RePEc/remo
#          New option $all_mirror_to controls which directory the core mirror
#          mirrors to. Default is $local_mirror/all. This will typically be 
#          RePEc/remo/all and is different from the previous hardcoded
#          RePEc/all.
#        - Logs are now e-mailed also for the core mirror.
#        - Consistent naming of by archive log and configurarion files for 
#          mirror and w3mir. They are now named as mirror_x_abc and w3mir_x_abc
#          where abc is the archive code and x indicates the mirroring action, all. a or s.
#        - Minor improvement to parsing of w3mir error messages (BOGUS HTTP REPLY)
#        - Made w3mir's parsing of http headers more forgiving, will not choke on replys
#          where the status line is terminated immediately after the code. Now uses
#          w3http4remi.pm.
#        - Turned off sending a From: header in w3mir since this was leaking account names/e-mail addresses.
#  -- 2005-05-10, 1.4b
#        - Fixed w3mir4remi.pl to work with URI v 1.32 and greater.
#        - Fixed w3mir4remi.pl to decode URL-encoded URLs for local file name
#        - Changed w3mir4remi.pl to do a retry on internal error 98 (network error)
#        - Fixed mirror4remi.pl to make parsing of response to PASV 
#          command more forgiving. Now uses ftp4remi.pl instead of
#          ftp.pl from mirror distribution.
#        - Fixed sending of e-mails to conform better to SMTP spec.
#        - Added $homepage option to config. This is put in w3mir browser
#          string instead of $maintaineremail if present.
#  -- 2004-11-11, 1.4a
#        - Removed recurse from w3mir options with type_to_get='all',
#          Turned out to be a bad idea. Instead, some additional
#          mods where made to w3mir to make it check if we want a 
#          document on redirection with the batch option.
#        - Now records runtimes for killed processes with -paralell.
#        - Better time stamps in log with -paralell
#  -- 2004-07-29, 1.4
#        - Added ability to run mirror and w3mir in parallel. This can
#          speed up the mirroring process considerably.
#          Setting $parallel to a positive number enables this feature
#          and will run that many parallel processes (also -parallel 
#          command line option). 
#          ABSOLUTELY requires that mirror4remi.pl and w3mir4remi.pl are 
#          used. $mirror_timeout and $w3mir_timeout should also be set.
#          In order to minimize overall run time the slowest archives 
#          are scheduled for mirroring first based on the times from the
#          previous remi run. A side effect of this is the mirror and
#          w3mir logs do not list the results in alphabetical order.
#          Instead the results are listed in the order the processes
#          are harvested.
#          Set $dont_use_runtimes to a non-zero value to schedule
#          mirroring in alphabetical order with $parallel.
#          The run times are saved in runtimes.dat in the tmp directory.
#          The run times are not used for scheduling when mirroring
#          series and archive templates to the core site.
#          $log_parallel controls logging of this feature.
#        - Updated all.sub
#        - Added Fetch-RE and Options recurse to w3mir config for $type_to_get='all'
#          (mirroring of archive and series templates to core site). This avoids
#          redirection of this mirroring operation, tended to overwrite archive templates
#          and thrash things.
#        - Added $all_mirror and $all_only config settings. These now control 
#          mirroring to the all archive. $all_mirror enables this mirroring and
#          $all_only causes the script to exit and not run a standard mirror of all
#          archives.
#        - Added -fakeall option to simulate mirroring of archive and series templates
#          to the core site
#        - Added -coreonly option to only mirror core site
#        - Added -quiet option to suppress output from remi
#  -- 2002-06-26, 1.3a
#        - Added check of return value from 'kill' when timing out mirror and w3mir
#  -- 2002-06-19, 1.3
#        - Allow specification of which Perl to use when running mirror and w3mir
#          $perl_to_use option
#        - Changes to remi.conf
#          - @special_mirror and @special_w3mir no longer used
#            Setting $mirror_timeout and $w3mir_timeout enables running
#            the mirroring of each archive as separate processes, this way
#            mirror and w3mir can be killed if they hang
#          - Semantics of $mirror and $w3mir option changed, these
#            should now just specify the full path to the scripts
#          - New option $perl_to_use allows specifying the Perl executable 
#            used to run mirror and w3mir
#            0, '', or undefined - just execute the script
#            1 - use same Perl, eq $^X, as the one running remi
#            string, eq '/my/perl/perl_executable' - use this Perl
#        - Better parsing of mirror log for errors.
#        - Fixed som code in all.sub (parse_date) that works in Perl 5.6 but fails in 5.8
#        - Additional tweaks to mirror4remi.pl, prevent infinite recursion with recurse_hard
#          and directory names containing only whitespace
#          You SHOULD use mirror4remi.pl unless you override the current default of
#          recursing hard.
#        - Changed spawning of processes running mirror and w3mir to use open with a pipe
#          instead of the system( 1, ... ) construct which appears to only work on Win32.
#  -- 2002-05-29, 1.2b
#       - Check that temp directory specified with $tmp in remi.conf exists.
#         Creates directory otherwise.
#       - Improved handling of http servers that sends text/html as content-type
#         for .rdf files. ABSOLUTELY REQUIRES that the modified version of w3mir,
#         w3mir4remi.pl, is used. This modifies w3mir to check that a document matches
#         a regexp specified with the Canon-RE keyword in w3mir config file. This way
#         we can make sure that only html docs are "canonized".
#       - Stricter check of validity of archive and series handles.
#       - Some changes to facilitate showing maintainers what is happening in
#         the mirroring process.
#         Writes a error log file remi_err.log indicating which archives had errors
#         Writes a separate log file for each ftp archive if @special_mirror is used.
#         @special_mirror now REQUIRES that the modified mirror.pl, mirror4remi.pl, is used.
#         Writes a less cryptic message in the w3log indicating the URL we are mirroring
#       - Added the ability to do ftp to non-standard ports. This turns on the PASV option
#         since this seems to work better.
#       - Enforced some more defaults in the mirror packages, this may be more aggressive
#         with deleting files than the default mirror settings. Use mirror_options in
#         remi.conf to override this.
#       - Changed mirror to recurse hard.This works even with sites that does not support
#         recursive directory listings
#       - Changed from old rr.pm interface to ReDIF-Perl 2 interface for reading ReDIF files
#         Will not work with older ReDIF-Perls!
#       - Removed $RedifDir/remo/all/soft/RePEc from @INC
#       - Added dir of remi file to @INC (to get a standard location for all.sub)
#  -- 2001-10-28, 1.2a
#       - Special case for Win NT?. Lack of alarm() and proper implementation of signals
#         causes w3mir to hang rather than time out. Set $w3mir_timeout to a large value
#         in remi.conf and remi will kill the w3mir process if it runs longer than
#         $w3mir_timeout. REQUIRES A MODIFIED W3MIR SCRIPT and that @special_w3mir
#         points to how this should be run in remi.conf. See readme.txt.
#       - Avoid getting _directories created by frontpage
#       - Make running of mirror.pl more robust by running mirror separetely for
#         each archive. A little slower but allows us to kill the process if it
#         takes too long. Set $mirror_timeout to a positive value in remi.conf and
#         define @special_mirror to enable this.
#       - Does not use xxxmirr.rdf template. All settings now in remi.conf or by
#         command line options
#  -- 2001-02-09, 1.1c
#       - Pruning of w3.log, removing lines reporting that file is unchanged.
#         These lines are still available in the w3mir_?_xxx.tmp.log files.
#       - Better reading of conf-file, won't read all.conf if remi.conf is found.
#       - Bug with w3mir on netec.mcc.ac.uk
#       - Prevent writing user and group lines to mirror packages if on Win NT
#         since they cause mirror.pl to fail.
#  -- 2000-12-08, 1.1b
#       - Bugfix of @INC setting. Didn't add all/soft/$archive to @INC.
#         all.sub MUST now be in all/soft/$archive.
#  -- 2000-11-14, 1.1a
#       - Uses ReDIF-Perl 2.14 or later with all field values read in as arrays.
#       - Uses ReDIF::initialize() for initialization
#       - Slightly changed behaviour of series-(include|exclude) and
#         archive-(include|exclude) fields in xxxmirr.rdf. Will now concatenate
#         values from all fields of the same type.
#       - Uses first occurence of URL in archive templates.
#       - Changed name of conf-file from all.conf to remi.conf, looks for all.conf
#         if remi.conf isn't found.
#       - Made the authority configurable via remi.conf, $authority, $all_host
#         and $all_remote_dir variables.
#         Defaults to RePEc, netec.mcc.ac.uk and /pub/NetEc/RePEc/all.
#       - Changed parsing of command line arguments, now accepts '-conf' as well
#         as '--conf'. Still case sensitive. (rdir must still by --rdir due to
#         ReDIF::initialize)
#       - Added option -nocore to skip mirroring of authority.
#       - Added CONF variable $mirror_options to add local options to
#         mirror packages written by remi.
#       - Added remi.log info to mailed log file.
#       - Minor modifications to all.sub.
#       - Attempt to parse out error messages from log files and put them
#         at top of mailed log file.
#       - Changed the way w3mir is run to accomodate parsing of errors.
#  -- 1999-07-19, 1.02h
#       - Removed special case for wustl.edu and template reading.
#       - Changed to reading directories straight rather than using
#         File::Find due to problems with symlinks at netec.mcc.ac.auk.
#       - Added some additional checks on correctness of templates.
#  -- 1999-03-30, 1.02g
#       - Added 6-character-no-period "file" name to Fetch-RE regexp for
#         for w3mir. This way we get the series directories even when the
#         directory isn't terminated with a / as it should be in directory
#         listings.
#       - Added error message for attempts to mirror nonexistent archives
#         or series for which we have no archive.
#       - Added check if we have something to mirror by FTP.
#       - Slightly improved logging.
#       - Added user agent to w3mir telling who we really are and giving
#         contact e-mail for mirror maintainer, same as password for anonymous FTP.
#       - Fixed count of archives in RePEc, it was off by 1.
#       - Nuked $rere variable, not used anymore
#  -- 1999-01-13, 1.02f
#       - Added (index|welcome|default)\.html*$ to Fetch-RE: regexp
#         for w3mir. Useful for http based archives with hand made
#         index.html file. Also made Fetch-RE: regexp case insensitive.
#  -- 1999-01-06, 1.02e
#       - Better understanding of how w3mir works.
#         Added "Ignore-RE: m!.*!\n" after Fetch-RE: in w3mir config file
#         if there is a $get_patt.
#         Modification of w3mir no longer needed!
#       - Fixed count of mirrored archives.
#       - Added $::RedifDir/remo/all/soft/RePEc back to @INC.
#       - Now logs failures sending mail.
#       - Added line to $w3log indicating what is mirrored. A little
#         bit easier to figure out where things go wrong that way.
#  -- 1998-12-21, 1.02d
#       - Fixed redirection on systems that don't like 1>file 2>&1
#         1>file 2>file is now default and we do the former for NT.
#       - Changed OS dependent flags to file globals, variable name in
#         uppercase.
#       - Removed $::RedifDir/remo/all/soft/RePEc from @INC
#  -- 1998-12-04, 1.02c
#       - Fixed redirection on NT, now uses 1>file 2>&1
#         This means that mirror.pl must be run using "perl mirror.pl" on
#         NT. The $mirror environment variable should be set accordingly
#         in all.conf.
#  -- 1998-11-25, 1.02b
#       - Switched to rr.pm for reading templates.
#         Template considered good if it passes the scrutiny of rr.
#         $remi_pedantic functionality discussed below no longer applies.
#       - Checks if we have an archive url and dumps series otherwise. Logs
#         this, probable error in archive template.
#       - Checks if archive and series handles have correct syntax and dumps
#         template otherwise. Logs this.
#       - Changed internal identification of series, now identifed by
#         archive-code:series-code pair. This should be unique. Was problem
#         with fth:yorken and yor:yorken when mirroring series.
#         This required modification to make_list. Now returns whatever is
#         after /^RePEc:/i if this matches. Otherwise no check of syntax.
#       - Discovered that mirror fails for the last package in $ftp_tmp if
#         there is more than one package in the file. Added work around
#         in the form of an empty package at the end of the file. This is only
#         done if we are on Win NT since I don't know if this is NT specific.
#       - "Things to fix?" below still applies, especially the thing about
#         netec.wustl.edu.
#
#  -- 1998-11-12, first 'public' version, 1.02a --
#       - Use strict and "-w" clean
#       - Added logic to read xxxmirr.rdf file with non-standard name
#         or location if specified on command line with --conf
#       - Removed defaults for $user and $group, these must be set in
#         the xxxmirr.rdf file if they are needed and should not be
#         set otherwise
#       - Nuked $grep, $find and $elm from all.conf - should not use external programs
#       - Added $mirror variable to all.conf to allow for mirror.pl in
#         non-standard location, mods for NT are currently overwritten
#         when all is mirrored
#       - Added $w3mir_options to all.conf to pass site specific arguments
#         to w3mir, this is written to the w3mir conf file as is
#       - Moved subroutines in all.conf to separate file all.sub.
#         Renamed &CONF::log to logger. Modified parse_date to use
#         built in functions rather than system call to get date.
#         Added sub smtp_send to send mail using Net::SMTP.
#       - Added delete of w3mir log file at start of run
#       - Replaced format with a sub to write packages for mirror
#       - Added update_log variable to mirror package if on system with
#         redirection problems
#       - Removed mail_to from mirror package for all
#       - Changed mirror password to be email in Maintainer-Email from
#         xxxmirr.rdf
#       - Changed logic for tacking on a '/' to the end of http URLs
#       - mirror_series passes $get_patt_option directly to write_for
#       - made remi check for existence of Handle in archive and series
#         templates and URL in archive template. Also checks that archive
#         part of handle is consistent with filename (this can be overridden
#         with $remi_pedantic = 0 in all.conf) and that we have a URL for this
#         archive.
#       - lowercases handles and makes parsing more forgiving about white space
#         after : in name: value pair
#       - made forgiving about trailing slash on ftp urls
#       - fixed http mirroring of series, now adds series directory to url
#       - mirror_series used to inherit $get_patt from
#         mirror_archives, as a result nothing was mirrored.
#       - fixed (hopefully) rewrite of $get_pat for w3mir. Now rewrites as
#         $get_patt =~ s!\^!$url!g;
#         Fetch-RE: m!$get_patt|/\$!\n;
#         This requires a modification to w3mir (v. 1.0.5), since Fetch-RE is broken
#         (the sub testing the thing returns true even when the Fetch-RE
#         doesn't match), change line 2019
#                $rule_text.=' return 1 if '.$expr.";\n";
#         to
#                $rule_text.=' return ( '.$expr." ? 1 : 0 );\n";
#       - Added command line switch --inc to put directory on top of @INC.
#         This makes it possible to have two all.conf, one for 'old' remi in
#         REDIFDIR/conf and one for 'new' remi in the --inc directory. The latter
#         is also a good place for all.sub and the modified mirror and w3mir scripts
#       - Cleaned up BEGIN code a little
#       - Messed with using rr.pm to read templates, required some
#         modifications in BEGIN code to set upp variables needed by rr.pm
#       - Currently bypasses rere and reads the templates raw.
#
#   Things to fix ?
#       * Mirroring of individual series currently wasteful (Series-Exclude:
#         and Series-Include in mirror template. It first
#         wipes out all templates in the local series directory when
#         mirroring the arch and seri templates for the archive, then
#         gets them again. Series-Exclude is especially bad since
#         it first wipes out everything and then gets almost all series.
#         Should probably not use Option: recurse with w3mir when mirroring
#         series.

use strict;

use Cwd;         # Standard Perl 5 library module
use ReDIF::Parser qw( &redif_open_file
                      &redif_get_next_template_good_or_bad
                      &redif_set_parser_options );
use File::Copy;
use File::Path;

my ( $ConfFile, $RedifDir, $ProgID, $dont_mirror_authority, $fake_all_mirror, 
     $all_mirror, $all_only,
     $authority_only, $quietmode, $makeallold,
     $ProgrammName,
     $ProgrammVersion, $ProgrammDescription, $ProgrammAuthor,
     $ProgrammAuthorEmail );

# new stuff for replacing xxxmirr.rdf
my ( $redifonly, $mirrarchives, $mirrXarchives,  
     $parallelopt );

redif_set_parser_options( 
                          'remove_newline_from_values' => 1,
                          'utf8_output' => 1, 
                        );

#   Process command line arguments

###################################
# Change these variables at least #
###################################
$ProgrammName         = "remi";
$ProgrammVersion      = "2.06";
$ProgrammDescription  = "Mirror remote archives";
$ProgrammAuthor       = "Sune Karlsson";
$ProgrammAuthorEmail  = 'Sune.Karlsson@oru.se';


  $ProgID = "$ProgrammName $ProgrammVersion";

  my $help = <<_HELP_;
- $ProgrammName v$ProgrammVersion ($ProgrammDescription) -
    NT port by $ProgrammAuthor ($ProgrammAuthorEmail)
    Original script by J M Barrueco
Usage:
  $0
    [-arch arch1 arch2 ..., archives to mirror] 
    [-conf, alternate remi.conf]
    [-inc dir, adds dir to \@INC] 
    [-quiet, minimize output]
    [-nocore, do not mirror core site] 
    [-coreonly, only mirror core site]
    [-fakeall, mirror archive and series templates into fake_all, for testing]
    [-parallel n, run n mirroring process in parallel, n = 0 runs serially]
    [-makeallold, resets modification time for the .rdf/.redif files in all to 1997-01-01]
    [-?|h]
    options with double dash are ignored and passed to ReDIF-Perl. e.g.
    [--rdir REDIFDIR]

_HELP_

  my( $incDir, $dir, $t, $s, $ss, @confs, $arg );

  @confs = ( 'remi.conf', 'all.conf' );
  $dont_mirror_authority = $fake_all_mirror = $authority_only = $makeallold = 0;

  my @args = @ARGV;
  while( @args ) {

    $arg = lc( shift @args );

    if ( $arg =~ /^-conf/ ) {
      $ConfFile = shift @args or die "Incomplete command line argument $arg";
      @confs = ( $ConfFile );
    } elsif ( $arg =~ /^-inc/ ) {
      $incDir = shift @args or die "Incomplete command line argument $arg";
      die "No directory $incDir" unless ( -d $incDir );
    } elsif ( $arg =~ /^-fakeall/ ) {
      $fake_all_mirror = 1;
      $all_only = 1;
    } elsif ( $arg =~ /^-nocore/ ) {
      $dont_mirror_authority = 1;
    } elsif ( $arg =~ /^-coreonly/ ) {
      $authority_only = 1;
    } elsif ( $arg =~ /^-quiet/ ) {
      $quietmode = 1;
    } elsif ( $arg =~ /^-makeallold/ ) {
      $makeallold = 1;
    }

    ## options that also can be set in remi.conf

    elsif ( $arg =~ /^-arch/ ) {
      $mirrarchives = '';
      $arg = lc( shift @args ) or die "Incomplete command line argument $arg";
      while ( $arg and $arg !~ /^-/ ) {
        $mirrarchives .= " $arg";
        $arg = @args ? lc( shift @args ) : '';
      }
      unshift @args, $arg if $arg;
    } elsif ( $arg =~ /^-parallel/ ) {
      die "Incomplete command line argument $arg" unless @args;
      $parallelopt = shift @args;
      die "-parallel must have numeric argument" unless $parallelopt =~ /^\d+$/;
    }

    ##

    elsif ( $arg =~ /^--/ ) {
      # assume this is for ReDIF-Perl, eat argument and ignore
      $arg = lc( shift @args ) or die "Incomplete command line argument $arg";
    }
    elsif ( $arg =~ m![-/]+[h?]! ) {
      print $help;
      exit;
    }
    else {
      print "Unknown command line argument: $arg\n";
      print $help;
      exit;
    }

  }

  ReDIF::initialize( { 'print_results' => !$quietmode } );

  if ( ( $RedifDir = $ReDIF::CONFIG{'redif_home'} ) =~ s![\\/]([a-z]{3})[\\/]?$!!i ) {
    $dir = $RedifDir.'/remo/all';
    die "Can not find your all directory: $t\n" unless ( -e $dir and -d $dir );
    }
  else {
    die "Strange redif_home $ReDIF::CONFIG{'redif_home'} from ReDIF::initialize\n";
    }

  # read config
  $ss = 0;
  foreach $t ( @confs ) {
    $s = "$ReDIF::CONFIG{'redif_home'}/conf/$t";
    if ( -e $s ) {
      require $s;
      print "remi configuration: $s\n" unless $quietmode;
      $ss = 1;
      last;
      }
    }
  die "Could not locate " . join( " or ", @confs ) . " in $ReDIF::CONFIG{'redif_home'}/conf\n"
    unless $ss;

  # Default values for authority
  # Authority, default is 'RePEc'
  $CONF::authority ||= 'RePEc';


  unshift @INC, $incDir if ( $incDir );

# detect OS
my $WinNT = 1 if $^O =~ /MSWin32/i;

# get directory where remi resides, add to @INC to find all.sub
$dir = $0;
if ( $WinNT ) {
  $dir =~ s!\\[^\\]+$!!;
} else {
  $dir =~ s!/[^/]+$!!;
}
unshift @INC, $dir if -d $dir;



#############################################################################
#
# MAIN
#
############################################################################

#
# Declare variables
#
my( $err, @fields, $local_host, $remo_dir, @errs,
    $mail_err, @archives, %url, %archfiles, $nbad, $nduplicate, @tmp, @files, $file, @dont_get,
    $type_to_get, @arch, $mirr_pass, %mirr_error, %WEB_ERROR,
    $UNIX_FILE_PERMS, $REDIRECT_STYLE, $ONE_LINE_STYLE, %TO_MIRROR,
    @RUN_FIRST, %RUN_WAIT );

#
# required modules
#

require 'all.sub';            # RePEc common(?) subroutines


#
# host for all archive for authority
# this is RePEc specific
$CONF::all_host ||= 'all.repec.org';
# directory to get
$CONF::all_remote_dir ||= '/RePEc/all';

#
# some variables
#
my $log_file=$CONF::log.'/remi.log' ;
my $err_log = $CONF::log.'/remi_err.log' ;
my $mirror_log=$CONF::log.'/mirror.log' ;
my $weblog=$CONF::log.'/web.log' ;
my $webtmplog = '.tmp.log';
my $ftp_tmp=$CONF::tmp.'/remi.ftp.tmp' ;
my $http_tmp=$CONF::tmp.'/remi.http.' ; # will add to this one later on depending on OS
my $arcnum=0 ;
my $do_deletes='true' ;
my $dir_mode='0755' ;
my $file_mode='0644';
my $HTTP_Agent = "$ProgID/webmirror";    # add contact info later on

# how many tmp log files to keep around
$CONF::logfiles2keep ||= 0;
# mirror and webmirror logs
$CONF::mainlogs2keep ||= 0;
# error log
$CONF::errlogs2keep ||= 0;
# remi log, note different semantics
$CONF::remilogs2keep = -1 if !defined $CONF::remilogs2keep;


#
# default values for mirror process
my( $maintainer_all, @to_get, $constraint_type );
my $user = "";
my $group = "";
my $get_patt_option = "";
my $alphaschedule = $CONF::dont_use_runtimes || 0;

# easier reference to %::HashT and avoid -w warnings
#%::HashT = %::HashT;
#my( $T ) = \%::HashT;
my( $T );

#
# set flags to adapt to different OS capabilities
#

# flag use of unix-type file permissions
if ( !$WinNT ) {
    $UNIX_FILE_PERMS = 1;
    }
else {
    $UNIX_FILE_PERMS = 0;
    }

# make file names "executable" on OSes that don't use file
# permissions to flag this
# no function rigth now
#if ( $UNIX_FILE_PERMS ) {
#    $http_tmp .= "tmp";
#    }
#else {
#    if ( $WinNT ) {
#        $http_tmp .= "bat";
#        }
#    }
$http_tmp .= "tmp";

# flag type of redirection to use
$REDIRECT_STYLE = 0;    # 1>file 2>file
if ( $WinNT ) {
  $REDIRECT_STYLE = 1;  # 1>file 2>&1
  }

# How to write one-liners
$ONE_LINE_STYLE = 0;      # Single quotes
if ( $WinNT ) {
  $ONE_LINE_STYLE = 1;    # Double quotes
  }

#
# rotate log files
#
$err = log_rotate( $mirror_log, $CONF::mainlogs2keep );
logger( 1, $err, $log_file, 1 ) if $err;
$err = log_rotate( $weblog,      $CONF::mainlogs2keep );
logger( 1, $err, $log_file, 1 ) if $err;
$err = log_rotate( $err_log,    $CONF::errlogs2keep );
logger( 1, $err, $log_file, 1 ) if $err;
if ( $CONF::remilogs2keep >= 0 ) {
  $err = log_rotate( $log_file,    $CONF::remilogs2keep );
  logger( 1, $err, $log_file, 1 ) if $err;
}

&logger('1',"New remi ($ProgrammVersion) process starts now in $RedifDir",$log_file,1) ;
&logger('1','NOTE that the $w3mir setting in remi.conf is obsolete, use $webmirror.', $log_file,1) if $CONF::w3mir;
&logger('1','NOTE that the $w3mir_options setting in remi.conf is obsolete.', $log_file,1) if $CONF::w3mir_options;
&logger('1','NOTE that the $w3mir_timeout setting in remi.conf is obsolete, use $web_timeout.', $log_file,1) if $CONF::w3mir_timeout;
&logger('1','NOTE that the $series setting in remi.conf is obsolete, remi2 does not mirror single series.', $log_file,1) if $CONF::series;
&logger('1','NOTE that the $Xseries setting in remi.conf is obsolete, remi2 does not exclude single series from mirroring.', $log_file,1) if $CONF::Xseries;

#
# find all directory. It may be specified in all.conf
#
my $all ;
if ( $CONF::local_all_directory ) {
  $all = $CONF::local_all_directory;
  }
else {
  $all = $RedifDir.'/remo/all';
  }
&logger('0',"I can not find your all directory, $all",$log_file,1) unless -d $all;

if ( $makeallold ) {
  # reset file times for .rdf files in all directory to 1997-01-01
  use Time::Local;
  logger('1', "Resetting file times for all directory $all", $log_file, 1 );
  my $ntime = timelocal( 0, 0, 0, 1, 0, 97 );
  my $files = set_time( $all, $ntime, '\.(?:rdf|redif)$' );
  logger('1', "File times set to 1997-01-01 for $files .rdf/.redif files", $log_file, 1 );
  exit;
}
  
$CONF::mirror ||= $all.'/soft/pbin/mirror/mirror.pl';
&logger('0',"Can not find mirror programme, $CONF::mirror",$log_file,1) unless ( -e $CONF::mirror );

&logger('0',"Can not find webmirror program, $CONF::webmirror",$log_file,1) unless ( -e $CONF::webmirror );

#
# Check for existence of temp directory
#
if (! -e $CONF::tmp) {
    &logger('1',"Temp directory $CONF::tmp does not exists. I will create it...",$log_file,!$quietmode) ;
    mkpath($CONF::tmp,1,0755)
    || &logger('0',"Sorry, I can not create temp directory $!",$log_file,1) ;
}


#
# New style argument processing instead of xxxarch.rdf
#


$local_host       ||= $CONF::machine;
$user             ||= $CONF::user;
$group            ||= $CONF::group;
$remo_dir         ||= $CONF::local_mirror_dir || $RedifDir.'/remo';
$maintainer_all   ||= $CONF::maintaineremail;
$redifonly        ||= $CONF::redifonly;
$all_only         ||= $CONF::all_only;
$all_mirror       ||= $CONF::all_mirror;

# override conf settings with command line arguments
if ( $mirrarchives ) {
  $CONF::Xarchives = undef;
  $CONF::run_first = undef;
  undef %CONF::run_wait;
}
if ( defined $parallelopt ) {
  $CONF::parallel = $parallelopt;
}
if ( $dont_mirror_authority ) {
  $CONF::nocore = $dont_mirror_authority;
}

if ( $CONF::parallel and !( $CONF::mirror_timeout and $CONF::web_timeout ) ) {
  logger( 1, "\$parallel != 0 ($CONF::parallel) without \$mirror_timeout and \$web_timeout. Parallel mirroring disabled", $log_file, 1 );
  $CONF::parallel = 0;
}

$mirrarchives     ||= $CONF::archives;
$mirrXarchives    ||= $CONF::Xarchives;

$dont_mirror_authority ||= $CONF::nocore;

$get_patt_option  = '^soft|^conf|\.([rR][dD][fF]|[rR][eE][dD][iI][fF])$'   if $redifonly;

if ( $mirrarchives ) {
  @to_get = &make_list( $mirrarchives );
  logger( 0, "No valid archives to mirror!", $log_file, 1 ) unless @to_get;
}
if ( $mirrXarchives ) {
  @dont_get = &make_list( $mirrXarchives );
  logger( 0, "No valid archives excluded from mirroring!", $log_file, 1 ) unless @dont_get;
}
if ( $CONF::run_first and $CONF::parallel ) {
  @RUN_FIRST = make_list( $CONF::run_first );
  logger( 1, "Archives $CONF::run_first scheduled to mirror first", $log_file, 1 );
}
if ( %CONF::run_wait ) {
  foreach $t ( keys %CONF::run_wait ) {
    if ( $t =~ /^$CONF::authority:(\w{3})$/i ) {
      $RUN_WAIT{$1} = $CONF::run_wait{$t};
      logger( 1, "Archive $t scheduled to run after $CONF::run_wait{$t} hour", $log_file, 1 );
    } else {
      logger( 1, "Archive $t in \%run_wait{$t} not valid.", $log_file, 1 );
    }
  }
}

if ( $maintainer_all ) {
  $mirr_pass = $maintainer_all;
} else {
  &logger('0',"maintaineremail: required in remi.conf",$log_file,1) ;
}


$HTTP_Agent .= $CONF::homepage ? " ($CONF::homepage)" : " ($maintainer_all)";
$HTTP_Agent =~ s/\s/+/g;
#
# Checks that $remo_dir exists. Otherwise remi will create it.
#
if (! -e $remo_dir) {
    &logger('1',"Directory remo does not exists. I will create it...",$log_file,!$quietmode) ;
    mkpath($remo_dir,1,0755)
    || &logger('0',"Sorry, I can not create remo directory $!",$log_file,1) ;
}

#
# We mirror the core site, unless explicitly requested not to
#
&mirror_all( $local_host, $all, $mirr_pass, $do_deletes, $user, $group,
             $ftp_tmp, $log_file, $CONF::mirror,
             $mirror_log, $webtmplog ) unless $dont_mirror_authority;

#
# Option usefull to mirror only the core site. 
#
if ( $authority_only ) {
    &logger('1',"Core site mirrored, exiting ....",$log_file,1) ;
    goto SEND_LOG;
}

#
# read archive templates now in all
#
unless ( opendir( D, $all ) ) {
  &logger('0',"Could not open $all directory for reading templates!",$log_file,1) ;
}
@files = sort readdir( D ) or
    &logger('0',"Could not read template names from $all directory!",$log_file,1) ;

closedir( D );

$nbad = $nduplicate = 0;
# archive templates
for $file ( @files ) {

  if ( $file =~ /arch\.(?:rdf|redif)$/i ) {
    my $archive = lc( $` );

    if ( redif_open_file( "$all/$file" ) ) {

      while( $T = redif_get_next_template_good_or_bad() ) {

        if ( $T->{RESULT} ne 'good' ) {
          $nbad++;
          next;
        }

        if ( $T->{'template-type'}[0] =~ /^ReDIF-Archive/i ) {
          $s = lc( $T->{handle}[0] );
          if ( $s =~ /^$CONF::authority:(\w{3})$/i ) {
            if ( $archive ne $1 ) {
              &logger( '1', "Handle $s does not match file name $file with archive template", $log_file, !$quietmode );
              $nbad++;
              next;
            } elsif ( $archfiles{$1} ) {
              &logger( '1', "Duplicate archive template for $1 in $file, IGNORING previous template in $archfiles{$1}.", $log_file, !$quietmode );
              $nduplicate++;
            } else {
              push @archives, $1;
            }
            $url{$1} = $T->{url}[0];
            $archfiles{$1} = $file;
            $arcnum++;
          } else {
            &logger('1',"Invalid archive handle $T->{handle}[0] in $file.",$log_file,!$quietmode) ;
            $nbad++;
          }
        } else {
          &logger('1',"Non-archive template in $file.",$log_file,!$quietmode) ;
          $nbad++;
        }
      }

    } else {

      &logger('1',"Could not read templates in $file.",$log_file,!$quietmode) ;

    }

  }

}
logger( 1, "$nbad bad archive templates", $log_file, !$quietmode ) if $nbad;
logger( 1, "$nduplicate duplicate archive templates", $log_file, !$quietmode ) if $nduplicate;

&logger('1',"Number of archives now in $CONF::authority $arcnum ",$log_file,!$quietmode) ;
$arcnum = 0;

if ( @RUN_FIRST ) {
  undef @tmp;
  foreach $t ( @RUN_FIRST ) {
    if ( $url{$t} ) {
      push @tmp, $t;
    } else {
      logger( 1, "Nonexisting archive $t scheduled to run first, ignored", $log_file, !$quietmode );
    }
  }
  @RUN_FIRST = @tmp;
}
if ( %RUN_WAIT ) {
  foreach $t ( keys %RUN_WAIT ) {
    unless ( $url{$t} ) {
      logger( 1, "Nonexisting archive $t scheduled to run after $RUN_WAIT{$t} hours, ignored", $log_file, !$quietmode );
      delete $RUN_WAIT{$t};
    }
  }
}

#
# If there is a constraint on the archives to mirror, this code
# computes the correct archives to mirror
#

if ( @dont_get ) {
  # exclude archives
  
  my(%temporaryarray) ;
  grep($temporaryarray{$_}++,@dont_get) ;

  @to_get = grep(!$temporaryarray{$_},@archives) ;

} elsif ( !@to_get ) {
  # mirror all archives

  @to_get = @archives;
  
}

#
# WARNING: Special option usefull ONLY for the core site
#
if ( $all_mirror or $fake_all_mirror ) {
  my( $ok, $notok, %allfiles, @tmparch );
  
  $alphaschedule = 1;
  $do_deletes='false' ;
  &logger('1',"Mirroring remote files for core site",$log_file,!$quietmode) ;
  $type_to_get='all';
  my $all_target = $CONF::all_mirror_to || "$remo_dir/all";
  $all_target = "$RedifDir/fake_all" if $fake_all_mirror;
  mkpath( $all_target, 1, 0755 );
  my $tmpall = "$CONF::tmp/all_tmpdir";
  rmtree( $tmpall ) if -e $tmpall;
  mkpath( $tmpall, 1, 0755 );
  # copy to temp directory
  my $ncopy = 0;
  unless ( opendir( D, $all_target ) ) {
    &logger('0',"Could not open target all directory for reading templates!",$log_file,1) ;
    }
  @files = sort readdir( D ) or
      &logger('0',"Could not read template names from target all directory!",$log_file,1) ;
  closedir( D );
  for $file ( @files ) {
    if ( $file =~ /(arch|seri)\.(?:rdf|redif)$/i ) {
      push @tmparch, lc( $` ) if $file =~ /arch/i;
      my $t = lc( $file );
      $t =~ s/rdf|redif//;
      if ( $allfiles{$t} ) {
        logger( 1, "WARNING multiple template files $file and $allfiles{$t} in all before mirroring" );
      }
      $allfiles{$t} = $file;
      $ok = my_copy( "$all_target/$file", "$tmpall/$file" );
      unless ( $ok ) {
        logger( 0, "FATAL ERROR copying template from all to tmp all directory [$all_target/$file]: $!, ABORTING", $log_file, 1 );
      }
      $ncopy++;
    }
  }
  &logger('1',"Copied $ncopy template files from $all_target to temp all directory $tmpall",$log_file,!$quietmode) ;

  @archives = @tmparch if $fake_all_mirror;
  my @first_tmp = @RUN_FIRST;
  undef @RUN_FIRST;
  my %wait_tmp = %RUN_WAIT;
  undef %RUN_WAIT;
  $arcnum = &mirror_archives( $type_to_get, $tmpall, $get_patt_option,
                              $local_host, $dir_mode, $file_mode, $user, $group,
                              $HTTP_Agent, $weblog, $log_file, $webtmplog,
                              $mirr_pass, $mirror_log, $do_deletes, $redifonly, \%url, @archives );
  &make_mirror ;
  &logger('1',"End of mirroring remote files for core site",$log_file,!$quietmode) ;
  @RUN_FIRST = @first_tmp;
  %RUN_WAIT = %wait_tmp;
  # check on mirrored files
  $ncopy = 0;
  unless ( opendir( D, $tmpall ) ) {
    &logger('0',"Could not open temp all directory for reading templates!",$log_file,1) ;
    }
  @files = sort readdir( D ) or
      &logger('0',"Could not read template names from temp all directory!",$log_file,1) ;
  closedir( D );
  undef %allfiles;
  for $file ( @files ) {
    if ( $file =~ /(arch|seri)\.(?:rdf|redif)$/i ) {
      my $t = lc( $file );
      $t =~ s/rdf|redif//;
      if ( $allfiles{$t} ) {
        logger( 1, "WARNING multiple template files $file and $allfiles{$t} in all after mirroring" );
      }
      $allfiles{$t} = $file;
      my $source = "$tmpall/$file";
      $notok = check_redif_file( $source );
      if ( $notok ) {
        logger( '1',"WARNING Invalid file not copied: $notok [$source]", $log_file, !$quietmode );
        next;
      }
      $ok = my_copy( $source, "$all_target/$file" );
      unless ( $ok ) {
        logger( 0, "FATAL ERROR copying template to all target [$all_target/$file]: $!, ABORTING", $log_file, 1 );
      }
      $ncopy++;
    }
  }
  &logger('1',"Copied $ncopy template files to $all_target from temp all directory $tmpall",$log_file,!$quietmode) ;

  $do_deletes='true' ;
  $alphaschedule = $CONF::dont_use_runtimes || 0;
  goto SEND_LOG if $all_only or $fake_all_mirror;

}

#
# Regular mirror of archives
#
$type_to_get='a' ;
$arcnum = &mirror_archives( $type_to_get, $remo_dir, $get_patt_option,
                            $local_host, $dir_mode, $file_mode, $user, $group,
                            $HTTP_Agent, $weblog, $log_file, $webtmplog,
                            $mirr_pass, $mirror_log, $do_deletes, $redifonly, \%url, @to_get );

#
# makes the mirror
#
&make_mirror ;

#
# Send email with the mirror_log contents
#
SEND_LOG:
undef @fields;
unless ( $CONF::shortlogmail ) {
  # get mirror and webmirror logs for e-mailing
  
  if ( open( TMP, "<$mirror_log" ) ) {
      @fields = ( "\n************************\nMirror log\n************************\n" );
      push @fields, ( <TMP> );
      close( TMP );
  } else {
      &logger('1','Could not read mirror (FTP) log for mailing',$log_file,!$quietmode); # if -s $ftp_tmp;
  }

  if ( open( TMP, "<$weblog" ) ) {
      push @fields, "\n************************\nWebmirror log\n************************\n";
      push @fields, ( <TMP> );
      close( TMP );
  } else {
      &logger('1','Could not read webmirror log for mailing',$log_file,!$quietmode); # if -s $http_tmp ;
  }

}

if ( keys %mirr_error ) {
  push @errs,  
     "\n************************\nErrors in mirror process\n************************\n";
  foreach $t ( sort keys %mirr_error ) {
    push @errs, @{$mirr_error{$t}};
  }
}

if ( keys %WEB_ERROR ) {
  push @errs,  
     "\n************************\nErrors in webmirror process\n************************\n";
  foreach $t ( sort keys %WEB_ERROR ) {
    push @errs, @{$WEB_ERROR{$t}};
  }
}

unshift @fields, @errs;

open( EL, ">$err_log" );
print EL @errs;
close( EL );

eval { $t = &get_log };
if ( $@ ) {
  # error, probably old all.sub
  unshift @fields, "Error retreiving remi log (you probably have an old all.sub): $@\n";
} else {
  unshift @fields, $t;
}

$mail_err = &smtp_send( $maintainer_all, "$CONF::authority mirror & webmirror logs", @fields ) if @fields;
&logger('1',$mail_err,$log_file,1) if $mail_err;

&logger('0','End of remi process',$log_file,1) ;


#############################################################################
#
# PROCEDURES
#
############################################################################

sub set_time {

my( $dir, $time, $filter ) = @_;

opendir( D, $dir ) or die "Could not open $dir: $!";
my @files = readdir( D );
close( D );

my $nfiles = 0;

foreach my $f ( @files ) {

  if ( $filter ) {
    next unless $f =~ /$filter/;
  }
  
  $nfiles += utime $time, $time, "$dir/$f";
  
}

return $nfiles;

}

sub my_copy {

my( $source, $target ) = @_;

my( @stime, @ttime, $ok );

@stime = (stat $source)[8..9];
if ( -e $target ) {
  @ttime = (stat $target)[8..9];
} else {
  @ttime = ( 0, 0 );
}
if ( $ttime[1] <= $stime[1] ) {
  $ok = copy( $source, $target );
} else {
  # avoid overwriting a newer file in real all directory
  return( 1 );
}

return( $ok ) unless $ok; # copy failed

@ttime = (stat $target)[8..9];

if ( $stime[1] != $ttime[1] ) {
  $ok = utime @stime, $target;
}

return $ok;

}

sub check_redif_file {
  
  use Encode qw( decode from_to );

  # basic check that a ReDIF file is valid.
  my( $file ) = @_;

  my $ok = 0;
  
  if ( redif_open_file( $file ) ) {

    while( $T = redif_get_next_template_good_or_bad() ) {

      next if ( $T->{RESULT} ne 'good' );

      if ( $T->{'template-type'}[0] =~ /^ReDIF-(Archive|Series)/i ) {
        $ok = 1;
        last;
      }
      
    }
    
    if ( $ok ) {
      return '';
    } else {
      return 'Not a valid Archive/Series template';
    }
    
  } else {
    
    return 'Could not open to check for valid template';
    
  }
  
}
        
#----------------------

sub make_mirror {

# Beware!
# uses file global variables

my( $arch, $m, $w );

&logger('1',"$arcnum archives mirrored",$log_file,!$quietmode) ;

if ( $CONF::parallel > 0 ) {
  # run in parallel
  
  run_parallel();
  
} else {
  # serial run

  $m = $w = 0;

  &logger('1',"Starting mirror process....",$log_file,!$quietmode) ;

  foreach $arch( sort keys %TO_MIRROR ) {

    if ( $TO_MIRROR{$arch}[0] eq 'mirror' ) {
      run_mirror( $TO_MIRROR{$arch}[1], $TO_MIRROR{$arch}[2], $TO_MIRROR{$arch}[3] );
      $m++;
    }

  }

  &logger('1',"Mirror process ended. $m sites. Please have a look at $mirror_log",$log_file,!$quietmode) ;

  &logger('1',"Starting webmirror process....",$log_file,!$quietmode) ;

  foreach $arch( sort keys %TO_MIRROR ) {

    if ( $TO_MIRROR{$arch}[0] eq 'webmirror' ) {
      run_web( $TO_MIRROR{$arch}[1], $TO_MIRROR{$arch}[2], $TO_MIRROR{$arch}[3], $TO_MIRROR{$arch}[4] );
      $w++;
    }

  }

  &logger('1',"Webmirror process ended. $w sites. Please have a look at $weblog",$log_file,!$quietmode) ;

}

}

#---------------------

sub write_for {

    my( $archive, $type_to_get, $proto, $remote_host, $remote_dir,
        $local_host, $local_dir, $dir_mode, $file_mode, $user, $group,
        $HTTP_Agent, $weblog, $log_file, $webtmplog, $mirror_log,
        $url, $get_patt, $mirr_pass, $do_deletes, $redif_only ) = @_ ;

    my( $web_conf );

    if ( $proto =~ /^ftp$/i ) {

      &write_mirror_package( $archive, $local_host, $remote_host,
                             $local_dir, $remote_dir, $get_patt,
                             $mirr_pass, $dir_mode, $file_mode, $do_deletes, $user,
                             $group, $mirror_log, $webtmplog );

    } elsif ( $proto =~ /^https*$/i ) {

      $url .= '/' unless ( $url =~ m!/(?:index|welcome|default)\.(?:html*|php|aspx*)$! or 
                           substr($url,-1,1) eq '/' );

      $web_conf = $CONF::tmp.'/web_'.$type_to_get.'_'.$archive;
      open(WEB,">$web_conf") or &logger('0',"Error opening webmirror cfg file $web_conf",$log_file,1) ;
      print WEB "-a $HTTP_Agent\n-u $url\n-m $local_dir";
      print WEB "\n-t" unless $redif_only;
      if ($type_to_get eq 'all') {
        print WEB "\n-archser $archive";
      }
      close(WEB);

      $TO_MIRROR{$archive} = [ 'webmirror', $web_conf, $weblog, "$web_conf$webtmplog", $url ];
        
    } else {
      
      logger( 1, "Invalid protocol, $proto, for archive $archive, only ftp, http and https", $log_file, 1 );
      push @{$WEB_ERROR{$archive}}, "$archive: remi: Invalid protocol, $proto, only ftp, http and https\n";
      
    }

}

#----------------------

sub write_mirror_package {

  my( $pack, $local_host, $remote_host, $local_dir, $remote_dir,
      $get_patt, $password, $dir_mode, $file_mode, $do_deletes, $user,
      $group, $log_file, $mirtmplog ) = @_;

my $archser = $pack;

my( $mirror_pack, $port );

  $pack =~ s/:/_/g;

  # extract non-standard ftp port
  if ( $remote_host =~ s/:(\d+)$// ) {
    $port = $1 unless $1 == 21;
  }

  # make root of server remote_dir if this is empty
  $remote_dir = '/' unless $remote_dir;
  
  $mirror_pack = $CONF::tmp.'/mirror_'.$type_to_get.'_'.$pack;
  open( MIRROR,">$mirror_pack") or &logger('0',"Error opening mirror package file $mirror_pack",$log_file,1) ;

  print MIRROR <<_END_PACK_;
package=$pack
        # our hostname
        hostname=$local_host
        # the site we wish to mirror from
        site=$remote_host
        remote_dir=$remote_dir
        # Keep all local_dirs relative to here
        local_dir=$local_dir
        # get this
        get_patt=$get_patt
        # but not directories starting with underscore (Frontpage)
        exclude_patt=^_.+/|/_vti_.+/
        remote_password=$password
        # Don't mirror file modes.  Set all dirs/files to these
        dir_mode=$dir_mode
        file_mode=$file_mode
        # By defaults files are owned by root.zero
        do_deletes=$do_deletes
        # some more defaults
        max_delete_files=100%
        max_delete_dirs=100%
        timeout=300
        # this is needed with sites that do not support recursive directory listings
        # slows down things a little bit
        recurse_hard=true
        # security fix
        name_mappings=s:\\.\\./:__/:g
_END_PACK_

# print MIRROR "        ftp_port=$port\n        passive_ftp=true\n" if $port;
# PASV seems to work best with a non-standard port
print MIRROR "        ftp_port=$port\n" if $port;
#print MIRROR "        passive_ftp=true\n" if ( ( $CONF::pasv_all and !$CONF::pasv_no{$remote_host} ) 
#                                             or $CONF::pasv_host{$remote_host}
#                                             or ( $CONF::pasv_non21 and $port ) );
print MIRROR "        passive_ftp=true\n" if ( ( ( $CONF::pasv_all or ( $CONF::pasv_non21 and $port ) )
                                                 and !$CONF::pasv_no{$remote_host} ) 
                                               or $CONF::pasv_host{$remote_host}
                                              );
print MIRROR "        flags_nonrecursive=$CONF::ls_flags{$remote_host}\n" if defined $CONF::ls_flags{$remote_host};
print MIRROR "        user=$user\n" if ( $user and !$WinNT );
print MIRROR "        group=$group\n" if ( $group and !$WinNT );
print MIRROR "        $CONF::mirror_options\n" if $CONF::mirror_options;

close( MIRROR );

$TO_MIRROR{$archser} = [ 'mirror', $mirror_pack, $log_file, "$mirror_pack$mirtmplog" ];


}

#----------------------

sub mirror_archives {

  my( $type_to_get, $remo_dir, $get_patt_option, $local_host,
      $dir_mode, $file_mode, $user, $group,
      $HTTP_Agent, $weblog, $log_file, $webtmplog,
      $mirr_pass, $mirror_log, $do_deletes, $redif_only, $url, @arch ) = @_ ;
#   $url is a hash deref, call with \%url

  my $previous="" ;
  my( $h_l, $arcnum, $proto, $remote_host, $remote_dir, $local_dir, @b, $h, $get_patt );

use URI;

#
# Now we make the packages to mirror archives
#

  $arcnum = 0;

  foreach $a (sort @arch) {

      if ( $a eq $previous ) {
        &logger('1',"Repeat occurence of archive $a",$log_file,!$quietmode) ;
        next;
      }

      unless ( $$url{$a} ) {
        &logger('1',"No valid archive template found for archive $a",$log_file,!$quietmode) ;
        next;
      }

      undef $h_l;
      $arcnum++ ;


      my $uri = URI->new( $url->{$a} );
      $proto = $uri->scheme();
      $remote_host = $uri->authority();
      $remote_dir = $uri->path();
      
      if ( substr($remote_dir,-1,1) eq '/' ) {
        # zap trailing slash
        substr($remote_dir,-1,1) = "";
      }
      if ( $type_to_get eq 'all' ) {
        $local_dir = $remo_dir;
      } else {
        $local_dir=$remo_dir.'/'.$a;
      }

      if ( $type_to_get eq 'all' ) {

        @b = split //, $a ;
        foreach $h (@b) {
          $h_l .= join '','[',$h,uc($h),']' ;
        }
        $get_patt='^'.$h_l.'\w{4}\.(?:[rR][dD][fF]|[rR][eE][dD][iI][fF])$' ;

      } else {
        $get_patt = $get_patt_option ;
      }

      &write_for ( $a, $type_to_get, $proto, $remote_host, $remote_dir,
                   $local_host, $local_dir, $dir_mode, $file_mode, $user, $group,
                   $HTTP_Agent, $weblog, $log_file, $webtmplog, $mirror_log,
                   $$url{$a}, $get_patt, $mirr_pass, $do_deletes, $redif_only );
      $previous = $a ;

  }

  return( $arcnum );

}

#----------------------

sub mirror_all {

    my( $local_host, $all_dir, $mirr_pass, $do_deletes, $user, $group,
        $ftp_tmp, $log_file, $mirror,
        $mirror_log, $mirtmplog ) = @_;

    &write_mirror_package( 'all', $local_host, $CONF::all_host, $all_dir,
                           $CONF::all_remote_dir, "", $mirr_pass, '0755',
                           '0755', $do_deletes, $user, $group, $mirror_log, $mirtmplog );

    &logger('1',"Mirroring core site ....",$log_file,!$quietmode) ;

    if ( $TO_MIRROR{all}[0] eq 'mirror' ) {
      run_mirror( $TO_MIRROR{all}[1], $TO_MIRROR{all}[2], $TO_MIRROR{all}[3] );
    } else {
      logger( 0, "Can only mirror core site by ftp!", 1 );
    }

    undef %TO_MIRROR;
    
    &logger('1',"End of mirroring core site ....",$log_file,!$quietmode) ;

}

#----------------------

sub make_list {

my( $fields ) = @_;
my(@items,$value,$item,@to_get_tmp) ;

#foreach $value ( @$fields ) {
  @items = split(/\s+/,$fields) ;
  foreach $item (@items) {
    next unless $item;
    if ( $item =~ /$CONF::authority:(.+)$/i ) {
      push(@to_get_tmp,$1);
    }
    else {
      logger( 1, "An item not in $CONF::authority requested or excluded: $item", $log_file, !$quietmode );
   }
  }
#  }

return( @to_get_tmp );

}

#----------------------

sub run_parallel {
  
use Storable;
use POSIX qw(sys_wait_h);
use IO::File;

my( $times, %time_by_arch, $arch, $pack, $command, $t,
    %childs, @harvest, $fh, %newtimes, $pid, $tpid, $mirrnum,
    @tomirror, @freemirrors, $err, $runtimes, $mcount, $wcount, %killed, $wallt,
    %mirrored, $warned_no_archive, $check_childs );

$times = "$CONF::tmp/runtimes.dat";

$wallt = time;
$warned_no_archive = $check_childs = 0;

%mirrored = map { $_, 1 } keys %TO_MIRROR;
# Anything that should be scheduled first?
foreach $t ( @RUN_FIRST ) {
  delete $mirrored{$t};
}
# Anything we should wait for?
foreach $t ( keys %RUN_WAIT ) {
  delete $mirrored{$t};
}

if ( $alphaschedule ) {

  @tomirror = sort keys %mirrored;

} else {
  
  $runtimes = retrieve $times if -e $times;
  %time_by_arch = map { ( $_, $runtimes->{$_} ? $runtimes->{$_} : 0 ) } keys %mirrored;
  @tomirror = sort { $time_by_arch{$b} <=> $time_by_arch{$a} } keys %mirrored;

}
@freemirrors = ( 1..$CONF::parallel );

$mcount = $wcount = 0;

while (1) {
  
  if ( scalar( keys %childs ) < $CONF::parallel and ( @tomirror or @RUN_FIRST or %RUN_WAIT ) and !$check_childs ) {
    # start new process

    $arch = '';
    # see if we have any special scheduling
    if ( @RUN_FIRST ) {
      $arch = shift @RUN_FIRST;
      logger( 2, "Scheduling $arch to run first.", $log_file, !$quietmode ) if $CONF::log_parallel;
    } elsif ( %RUN_WAIT ) {
      foreach $t ( keys %RUN_WAIT ) {
        if ( (time-$wallt) >= $RUN_WAIT{$t}*3600 ) {
          $arch = $t;
          logger( 2, "Scheduling $arch to run after $RUN_WAIT{$t} hours.", $log_file, !$quietmode ) if $CONF::log_parallel;
          delete $RUN_WAIT{$t};
          last;
        }
      }
      unless ( @tomirror ) {
        $t = join ' ', keys %RUN_WAIT;
        logger( 1, "Out of archives to mirror while waiting for $t by \$run_wait directive", $log_file, !$quietmode ) unless $warned_no_archive;
        $warned_no_archive = 1;
        # check childs next round
        $check_childs = 1;
      }
    }
    
    unless ( $arch ) {
      # regular order
      $arch = shift @tomirror;
    }
    next unless $arch; # nothing left to mirror, possible waiting for archive
    
    $mirrnum = shift @freemirrors;
    
    if ( $TO_MIRROR{$arch}[0] eq 'mirror' ) {

      ( $pack, $command ) = prep_mirror_run( $TO_MIRROR{$arch}[1], $TO_MIRROR{$arch}[2], $TO_MIRROR{$arch}[3] );
      $mcount++;

    } elsif ( $TO_MIRROR{$arch}[0] eq 'webmirror' ) {

      ( $pack, $command ) = prep_web_run( $TO_MIRROR{$arch}[1], $TO_MIRROR{$arch}[2], $TO_MIRROR{$arch}[3], $TO_MIRROR{$arch}[4], 0 );
      $wcount++

    } else {
      $err = "$arch: remi: unknown mirroring type '$TO_MIRROR{$arch}[0]'";
      logger( 1, $err, $log_file, !$quietmode );
      push @{$mirr_error{$arch}}, "$err\n";
      push @freemirrors, $mirrnum;
      next;
    }
    next unless $pack; # problem with tmp log
    
    # spawn process
    $fh = new IO::File;
    my $pid = open( $fh, '|'.$command );
    unless ( $pid > 0 ) {
      
      close( $fh );
      $err = "remi; Failed to spawn $command [$mirrnum]";
      logger( 1, $err, $log_file, !$quietmode );
      if ( $TO_MIRROR{$arch}[0] eq 'mirror' ) {
        push @{$mirr_error{$pack}}, "$pack: $err\n";
      } elsif ( $TO_MIRROR{$arch}[0] eq 'webmirror' ) {
        push @{$WEB_ERROR{$pack}}, "$pack: $err\n";
      }

    } else {

      $childs{$pid}{arch}  = $arch;
      $childs{$pid}{start} = time;
      $childs{$pid}{fh}    = $fh;
      $childs{$pid}{num}   = $mirrnum;
      # not in e-mailed log
      logger( 2, "[$mirrnum] Spawned $pid: $command", $log_file, !$quietmode ) if $CONF::log_parallel;
      
    }
    
  } else { 
    # check on child processes
  
    # go back and check if we are waiting for archive after having checked childs
    $check_childs = 0;
    
    undef @harvest;
    foreach $pid ( keys %childs ) {
      $tpid = waitpid( $pid, WNOHANG );
      push @harvest, $pid if ( $tpid == -1 or $tpid == $pid );
    }
  
    # harvest data
    foreach $pid ( @harvest ) {
  
      close( $childs{$pid}{fh} );
      $newtimes{$childs{$pid}{arch}} = time - $childs{$pid}{start};
      if ( $TO_MIRROR{$childs{$pid}{arch}}[0] eq 'mirror' ) {
        
        mirror_post_proc( $TO_MIRROR{$childs{$pid}{arch}}[1], $TO_MIRROR{$childs{$pid}{arch}}[2], $TO_MIRROR{$childs{$pid}{arch}}[3], $childs{$pid}{start}, '' );
        
      } elsif ( $TO_MIRROR{$childs{$pid}{arch}}[0] eq 'webmirror' ) {
        
        web_post_proc( $TO_MIRROR{$childs{$pid}{arch}}[1], $TO_MIRROR{$childs{$pid}{arch}}[2], $TO_MIRROR{$childs{$pid}{arch}}[3], $TO_MIRROR{$childs{$pid}{arch}}[4], $childs{$pid}{start}, '' );
  
      }
      # not in e-mailed log
      logger( 2, "[$childs{$pid}{num}] Harvested $pid for $childs{$pid}{arch}, $newtimes{$childs{$pid}{arch}} seconds", $log_file, !$quietmode ) if $CONF::log_parallel;
      push @freemirrors, $childs{$pid}{num}; 
      delete $childs{$pid};
      
    }
    
    # Should we kill any of the childs
    foreach $pid ( keys %childs ) {
      
      $t = time - $childs{$pid}{start};
      # default time out
      $s = $TO_MIRROR{$childs{$pid}{arch}}[0] eq 'mirror' ? $CONF::mirror_timeout : $CONF::web_timeout;
      # over ride default?
      $s = $CONF::archive_timeout{$childs{$pid}{arch}} if $s and $CONF::archive_timeout{$childs{$pid}{arch}};
      if ( $s > 0 and $t > $s ) {
        
        logger( 2, "[$childs{$pid}{num}] Killing $pid for $childs{$pid}{arch} after $t seconds", $log_file, !$quietmode ) if $CONF::log_parallel;
        my $e = kill 'KILL', $pid;
        $err = "$childs{$pid}{arch}: remi: $TO_MIRROR{$childs{$pid}{arch}}[0] timed out (killed) after $t seconds [$childs{$pid}{num}]";
        if ( $e <= 0 ) {
          $err .= "\n$childs{$pid}{arch}: remi: failed to kill $TO_MIRROR{$childs{$pid}{arch}}[0], return was $e";
          logger( 2, "Failed to kill $pid for $childs{$pid}{arch}", $log_file, !$quietmode );
        } else {
          # only close if a successful kill, we might hang on the close forever otherwise
          close( $childs{$pid}{fh} );
        }
        if ( $TO_MIRROR{$childs{$pid}{arch}}[0] eq 'mirror' ) {
          push @{$mirr_error{$childs{$pid}{arch}}}, "$err\n" if $err;
          mirror_post_proc( $TO_MIRROR{$childs{$pid}{arch}}[1], $TO_MIRROR{$childs{$pid}{arch}}[2], $TO_MIRROR{$childs{$pid}{arch}}[3], $childs{$pid}{start}, $err );
        } else {
          push @{$WEB_ERROR{$childs{$pid}{arch}}}, "$err\n" if $err;
          web_post_proc( $TO_MIRROR{$childs{$pid}{arch}}[1], $TO_MIRROR{$childs{$pid}{arch}}[2], $TO_MIRROR{$childs{$pid}{arch}}[3], $TO_MIRROR{$childs{$pid}{arch}}[4], $childs{$pid}{start}, $err );
        }
        $newtimes{$childs{$pid}{arch}} = time - $childs{$pid}{start};
        $killed{$childs{$pid}{arch}} = 1;
        push @freemirrors, $childs{$pid}{num};
        delete $childs{$pid};
        
      }
        
    }
  
    # check for exit condition
    unless ( keys %childs ) {
      # no childs to wait for
      last unless @tomirror or %RUN_WAIT or @RUN_FIRST;
    }
  
    # sleep
    select( undef, undef, undef, 2 );
  
  }

}

$wallt = time - $wallt;

unless ( $alphaschedule or $mcount+$wcount <= 1 ) {
  # save run times
  store \%newtimes, $times;
}

logger( 1, "Parallel run finished, $mcount ftp sites, $wcount http sites", $log_file, 1 );
my $maxt = 0;
my $maxa = '';
my $tott = 0;
foreach $arch ( keys %newtimes ) {
  next if $killed{$arch};
  if ( $maxt < $newtimes{$arch} ) {
    $maxt = $newtimes{$arch};
    $maxa = $arch;
  }
  $tott += $newtimes{$arch};
}
logger( 1, "Total parallell mirroring time: $tott seconds ($wallt wall time). Slowest archive is $maxa, $maxt seconds", $log_file, 1 );
if ( keys %killed > 0 ) {
  $arch = join( ", ", sort keys %killed );
  logger( 1, "Mirroring process timed out and killed for the following archives: $arch", $log_file, 1 );
}
if ( $tott > $maxt*$CONF::parallel ) {
  logger( 1, "It might be possible to speed up mirroring by increasing the number of processes, currently $CONF::parallel", $log_file, 1 );
}

}

#----------------------

sub prep_mirror_run {
  
  my( $mirror_pack, $mirror_log, $mirtmplog ) = @_;

  my( $pack, $err, $perl, $command );

  $mirror_pack =~ /_([a-z]+)$/;
  $pack = $1;

  $err = log_rotate( $mirtmplog, $CONF::logfiles2keep );
  if ( $err ) {
    push @{$mirr_error{$mirror_pack}}, "$mirror_pack: $err";
    open( L, ">>$mirror_log" );
    print L "package=$mirror_pack=\n$err\n";
    close( L );
    return( '', '' );
  }

  $perl = get_perl_to_use();
#if ( $pack =~ /fth|wop|fip|cod|wuk|rpc|nwe|wck|nom|els|cit|all/ ) {
#  $command = "$CONF::mirror -d -d -O$mirtmplog $mirror_pack";
#} else {
  $command = "$CONF::mirror -O$mirtmplog $mirror_pack";
#}
  $command = "$perl $command" if $perl;

  return( $pack, $command );
  
}

#----------------------

sub mirror_post_proc {

  my( $mirror_pack, $mirror_log, $mirtmplog, $t, $err ) = @_;

  my( @tmplog, $s, $run, $pack );
  
  $mirror_pack =~ /_([a-z]+)$/;
  $pack = $1;
  
  open( TL, "<$mirtmplog" );
  @tmplog = <TL>;
  close( TL );

  $s = time;
  $run = "Start: " . gmtime($t) . " GMT\nEnd:  " . gmtime($s) . " GMT\nTime: " . ($s-$t) . " seconds\n\n";

  open( TL, ">>$mirtmplog" );
  print TL "\n$err\n" if $err;
  print TL $run;
  close( TL );

  foreach ( @tmplog ) {
    push @{$mirr_error{$pack}}, "$pack: $_" if m/^(Cannot|Fail|Too many files|Insufficient details for package to be fetched)/i;
  }

  push @tmplog, "\n$err\n" if $err;
  push @tmplog, $run;

  open( L, ">>$mirror_log" );
  print L @tmplog;
  close( L );

}

#----------------------

sub run_mirror {

my( $mirror_pack, $mirror_log, $mirtmplog ) = @_;

my $t = time;
my( $err, @tmplog, $pack, $command, $perl );

use POSIX qw(sys_wait_h);

undef @tmplog;

if ( $CONF::mirror_timeout ) {

  ( $pack, $command ) = prep_mirror_run( $mirror_pack, $mirror_log, $mirtmplog );
  return( 1 ) unless $pack;

  my $countmax = $CONF::mirror_timeout/5; # wait 5 seconds between checks
  # override default?
  $countmax = $CONF::archive_timeout{$pack}/5 if $CONF::archive_timeout{$pack};
  
  print "running $command\n" unless $quietmode;
  my $pid = open( FH, '|'.$command );
  unless ( $pid > 0 ) {

    $err = "remi; Failed to spawn $command\n";
    print $err unless $quietmode;
    push @{$mirr_error{$pack}}, "$pack: $err";

  } else {

    print "Spawned $pid\n" unless $quietmode;

    my $waitsec = 0;
    while ( 1 ) {
      my $tpid = waitpid( $pid, WNOHANG );
      last if $tpid == -1 or $tpid == $pid;
      select( undef, undef, undef, 5 );
      $waitsec++;
      if ( $waitsec > $countmax ) {
        my $e = kill 'KILL', $pid;
        my $s = time-$t;
        $err = "remi: mirror timed out (killed) after $s seconds\n";
        if ( $e <= 0 ) {
          $err .= "$pack: remi: failed to kill mirror, return was $e\n";
        }
        push @{$mirr_error{$pack}}, "$pack: $err";
        last;
        }
      }

    mirror_post_proc( $mirror_pack, $mirror_log, $mirtmplog, $t, $err );
    
  }

  close( FH );


} else {

  $perl = get_perl_to_use();
  $command = "$CONF::mirror $mirror_pack";
  $command = "$perl $command" if $perl;
  if ( $REDIRECT_STYLE == 1 ) {
    $command .= " 1>>$mirror_log 2>>&1";
  } else {
    $command .= " 1>>$mirror_log 2>>$mirror_log";
  }
  print "running $command\n" unless $quietmode;
  system( $command );

  open( L, ">>$mirror_log" );
  print L "\n$err\n" if $err;
  print L "Time: " . (time-$t) . " seconds\n\n";
  close( L );

}

1; # ensure that remi.ftp.tmp returns true

}

#----------------------

sub prep_web_run {
  
  my( $web_conf, $weblog, $webtmplog, $url, $print ) = @_;

  use File::Find;
  
  my( $pack, $perl, $run, $err, $command, $dir, @files );
  
  $web_conf =~ /[a-z]{3}$/;
  $pack = $&;

  $perl = get_perl_to_use();

  open( L, ">>$weblog" );
  $run = "\nMirroring $pack at $url\n";
  print L $run if $print;

  $err = log_rotate( $webtmplog, $CONF::logfiles2keep );
  if ( $err ) {
    push @{$WEB_ERROR{$pack}}, "$pack: $err";
    print L "$err\n";
    close( L );
    return( '', '' );
  }
  close( L );

  $command = "$CONF::webmirror -c $web_conf -o $webtmplog";
  $command = "$perl $command" if $perl;
  
  return( $pack, $command );
  
}

#----------------------

sub web_post_proc {

  my( $web_conf, $weblog, $webtmplog, $url, $t, $err ) = @_;

  my( $pack, $run, $command, $s );
  
  $web_conf =~ /[a-z]{3}$/;
  $pack = $&;
  $run = "\nMirroring $pack at $url\n";
  
  open( TL, "<$webtmplog" );
  my @tmplog = <TL>;
  close( TL );

  open( TL, ">$webtmplog" );
  open( L, ">>$weblog" );
  print TL $run;
  print L $run;
  foreach ( @tmplog ) {
    push @{$WEB_ERROR{$pack}}, "$pack: $_" if m/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}: ERROR/;
    print L $_;
    print TL $_;
  }
  print L "\n$err" if $err;
  print TL "\n$err" if $err;
  $s = time;
  $run = "\nStart: " . gmtime($t) . " GMT\nEnd:  " . gmtime($s) . " GMT\nTime: " . ($s-$t) . " seconds\n";
  print L $run;
  print TL $run;
  close( L );
  close( TL );

}

#----------------------

sub run_web {

  my( $web_conf, $weblog, $webtmplog, $url ) = @_;

  my( $err, $run, $command, $pack, $perl );

  ( $pack, $command ) = prep_web_run( $web_conf, $weblog, $webtmplog, $url, !$CONF::web_timeout );
  
  my $t = time;

  if ( $CONF::web_timeout ) {

    use POSIX qw(sys_wait_h);
    my $countmax = $CONF::web_timeout/5; # wait 5 seconds between checks
    # override time out?
    $countmax = $CONF::archive_timeout{$pack}/5 if $CONF::archive_timeout{$pack};


    print "running $command\n" unless $quietmode;
    my $pid = open( FH, '|'.$command );
    unless ( $pid > 0 ) {

      $err = "remi: Failed to spawn $command\n";
      print $err unless $quietmode;
      push @{$WEB_ERROR{$pack}}, "$pack: $err";
      return 1;
      

    } else {

      print "Spawned $pid\n" unless $quietmode;

      my $waitsec = 0;
      while ( 1 ) {
        my $tpid = waitpid( $pid, WNOHANG );
        last if $tpid == -1 or $tpid == $pid;
        select( undef, undef, undef, 5 );
        $waitsec++;
        if ( $waitsec > $countmax ) {
          my $e = kill 'KILL', $pid;
          my $s = time-$t;
          $err = "remi: webmirror timed out (killed) after $s seconds\n";
          if ( $e <= 0 ) {
            $err .= "$pack: remi: failed to kill webmirror, return was $e\n";
          }
          push @{$WEB_ERROR{$pack}}, "$pack: $err";
            
        }
      }

    }
    close( FH );

  } else {

    $perl = get_perl_to_use();
    $command = "$CONF::webmirror -c $web_conf";
    $command = "$perl $command" if $perl;
    if ( $REDIRECT_STYLE == 1 ) {
      $command .= " 1>$webtmplog 2>&1";
    } else {
      $command .= " 1>$webtmplog 2>$webtmplog";
    }

    print "running $command\n" unless $quietmode;
    system( $command );

  }

  web_post_proc( $web_conf, $weblog, $webtmplog, $url, $t, $err );

  1; # return true, ensures that remi.http.tmp returns true

}

#----------------------

sub get_perl_to_use {
  
  my $perl = '';
  if ( $CONF::perl_to_use ) {
    if ( $CONF::perl_to_use eq '1' ) {
      $perl = $^X;
    } else {
      # user specified executable
      $perl = $CONF::perl_to_use
    }
  }

  return $perl;

}

#----------------------

sub log_rotate {

my( $logfile, $numtokeep ) = @_;

my( $base, $ext, $lognum, $file1, $file2 );

return undef unless -f $logfile;

if ( $logfile =~ /\.[^\.]+$/ ) {
  $base = $`;
  $ext = $&;
} else {
  $base = $logfile;
  $ext = '';
}

if ( $numtokeep <= 0 ) {

  if ( unlink $logfile ) {
    return undef;
  } else {
    return "remi: Failed to delete logfile $logfile, previous process might be hung";
  }

} else {
  
  $lognum = 1;
  while ( -e "$base.$lognum$ext" ) {
    $lognum++;
  }
  if ( $lognum >= $numtokeep ) {
    $lognum = $numtokeep;
    $file1 = "$base.$lognum$ext";
    unlink $file1 if -e $file1;
  }
  $file1 = "$base.$lognum$ext";
  while ( $lognum > 0 ) {
    $lognum--;
    if ( $lognum > 0 ) {
      $file2 = "$base.$lognum$ext";
    }
    else {
      $file2 = $logfile;
    }
    if ( -e $file2 ) {
      unless ( rename $file2, $file1 ) {
        return "remi: Failed to create backup $file1 of $file2: $^E";
      }
    }
    $file1 = $file2;
  }
  
}

}
